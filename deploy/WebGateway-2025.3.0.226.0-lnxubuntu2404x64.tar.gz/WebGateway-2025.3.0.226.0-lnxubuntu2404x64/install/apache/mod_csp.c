/* 
   Chris Munt: Interface between an Apache web server and the CSP NSD module.

   Cache Server Pages:

      +--------------------------------------------------------+
      | Copyright 1986-2017 by InterSystems Corporation,       |
      | Cambridge, Massachusetts, U.S.A.                       |
      | All rights reserved.                                   |
      |                                                        |
      | Confidential, unpublished property of InterSystems.    |
      |                                                        |
      | This media contains an authorized copy or copies       |
      | of material copyrighted by InterSystems and is the     |
      | confidential, unpublished property of InterSystems.    |
      | This copyright notice and any other copyright notices  |
      | included in machine readable copies must be reproduced |
      | on all authorized copies.                              |
      +--------------------------------------------------------+

*/


/* CMT805 */
/* CMT808 */
/* CMT1319 */
/* CMT1552 */

#define CSP_MODULE_TYPE             "apapi-nsd"
#define CSP_MODULE_BUILD            31
#define CSP_ADHOC_BUILD             3

/*
#define CSP_DEBUG                   1
*/

#define CSP_MAGIC_TYPE1             "application/x-csp"
#define CSP_MAGIC_TYPE2             "text/csp"

#define CSP_FILE_TYPES              ".csp.cls.zen.cxw."

#define CSP_DEFAULT_AP_TIMEOUT      300000

/* Operating System type */

#if defined(_WIN32) /* Windows */

#ifndef CSP_WIN32
#define CSP_WIN32                   1

#define CSP_WINSOCK2                1

#if defined(_MSC_VER)
#if (_MSC_VER >= 1400)
#define _CRT_SECURE_NO_DEPRECATE    1
#define _CRT_NONSTDC_NO_DEPRECATE   1

#define CSP_IPV6                    1

#endif
#endif

#endif

#else /* UNIX */

#ifndef CSP_UNIX
#define CSP_UNIX                    1
#endif

#define CSP_IPV6                    1


#endif

#ifdef _WIN32
#ifdef CSP_WINSOCK2
#define INCL_WINSOCK_API_TYPEDEFS   1
#include <winsock2.h>
#include <ws2tcpip.h>
#endif
#endif

#include "httpd.h"
#include "http_config.h"
#include "http_core.h"
#include "http_log.h"
#include "http_main.h"
#include "http_protocol.h"
#include "util_script.h"


#include "http_request.h"
#include "http_connection.h"
#include "apr_strings.h"


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifndef _WIN32
#include <strings.h>
#endif
#include <time.h>
#include <ctype.h>


#if defined(_WIN32)

#include <tchar.h>
#include <windows.h>
#include <winsock.h>
#include <fcntl.h>
#include <io.h>

#else /* CSP_UNIX */

#include <sys/signal.h>
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/param.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>
/*
#include <mach-o/ldsyms.h>
#include <mach-o/dyld.h>
*/

#endif


#define SA_IP_ADDRESS      "127.0.0.1"
#define SA_TCP_PORT        "7038"
#define SA_PID_FILE        "CSPnsd.pid"
#define SA_INI_FILE        "CSPnsd.ini"


#define CACHE_MAXSIZE      32767
#define CACHE_BUFFER       32768
#define CSP_MAXCON         32
#define CSP_TEMP_BUFFER    8192

#define SA_PATH_1          "/irissys/csp"
#define SA_PATH_2          "/usr/irissys/csp"
#define SA_PATH_3          "/etc"

#ifdef _WIN32
#define CSP_LOG_FILE       "C:/mod_csp.log"
#else
#define CSP_LOG_FILE       "/tmp/mod_csp.log"
#endif


typedef apr_pool_t               pool;
typedef apr_table_t              table;
#define SERVER_ERROR             HTTP_INTERNAL_SERVER_ERROR

#define CSP_PCALLOC              apr_pcalloc
#define CSP_TABLE_GET            apr_table_get
#define CSP_TABLE_DO             apr_table_do
#define CSP_TABLE_SET            apr_table_set
#define CSP_TABLE_ADD            apr_table_add
#define CSP_TABLE_ADDN           apr_table_addn
#define CSP_PSTRCAT              apr_pstrcat
#define CSP_PSTRDUP              apr_pstrdup
#define CSP_MAKE_TABLE           apr_table_make
#define CSP_MAKE_SUB_POOL        apr_create_pool
#define CSP_DESTROY_POOL         apr_pool_destroy

#define CSP_RWRITE               ap_rwrite
#define CSP_RFLUSH               ap_rflush
#define CSP_RPRINTF              ap_rprintf
#define CSP_RPUTS                ap_rputs
#define CSP_SOFT_TIMEOUT         ap_soft_timeout
#define CSP_RESET_TIMEOUT        ap_reset_timeout
#define CSP_KILL_TIMEOUT         ap_kill_timeout
#define CSP_SHOULD_CLIENT_BLOCK  ap_should_client_block
#define CSP_SETUP_CLIENT_BLOCK   ap_setup_client_block
#define CSP_ADD_CGI_VARS         ap_add_cgi_vars
#define CSP_GET_CLIENT_BLOCK     ap_get_client_block
#define CSP_ADD_COMMON_VARS      ap_add_common_vars
#define CSP_SEND_HTTP_HEADER     ap_send_http_header
#define CSP_GET_MODULE_CONFIG    ap_get_module_config

#ifdef CSP_WINSOCK2

#define CSPNET_WSASOCKET               csp_sock.p_WSASocket
#define CSPNET_WSAGETLASTERROR         csp_sock.p_WSAGetLastError
#define CSPNET_WSASTARTUP              csp_sock.p_WSAStartup
#define CSPNET_WSACLEANUP              csp_sock.p_WSACleanup
#define CSPNET_WSAFDISET               csp_sock.p_WSAFDIsSet
#define CSPNET_WSARECV                 csp_sock.p_WSARecv
#define CSPNET_WSASEND                 csp_sock.p_WSASend
#define CSPNET_CLOSESOCKET             csp_sock.p_closesocket
#define CSPNET_GETHOSTBYNAME           csp_sock.p_gethostbyname
#define CSPNET_GETADDRINFO             csp_sock.p_getaddrinfo
#define CSPNET_FREEADDRINFO            csp_sock.p_freeaddrinfo
#define CSPNET_HTONS                   csp_sock.p_htons
#define CSPNET_HTONL                   csp_sock.p_htonl
#define CSPNET_CONNECT                 csp_sock.p_connect
#define CSPNET_INET_ADDR               csp_sock.p_inet_addr
#define CSPNET_SOCKET                  csp_sock.p_socket
#define CSPNET_SETSOCKOPT              csp_sock.p_setsockopt
#define CSPNET_GETSOCKOPT              csp_sock.p_getsockopt
#define CSPNET_SELECT                  csp_sock.p_select
#define CSPNET_RECV                    csp_sock.p_recv
#define CSPNET_SEND                    csp_sock.p_send
#define CSPNET_SHUTDOWN                csp_sock.p_shutdown
#define CSPNET_BIND                    csp_sock.p_bind

#define  CSPNET_FD_ISSET(fd, set)      csp_sock.p_WSAFDIsSet((SOCKET)(fd), (fd_set FAR *)(set))

typedef int (WINAPI * LPFN_WSAFDISSET) (SOCKET, fd_set FAR *);

#else

#define CSPNET_WSASOCKET               WSASocket
#define CSPNET_WSAGETLASTERROR         WSAGetLastError
#define CSPNET_WSASTARTUP              WSAStartup
#define CSPNET_WSACLEANUP              WSACleanup
#define CSPNET_WSAFDISET               WSAFDIsSet
#define CSPNET_WSARECV                 WSARecv
#define CSPNET_WSASEND                 WSASend
#define CSPNET_CLOSESOCKET             closesocket
#define CSPNET_GETHOSTBYNAME           gethostbyname
#define CSPNET_GETADDRINFO             getaddrinfo
#define CSPNET_FREEADDRINFO            freeaddrinfo
#define CSPNET_HTONS                   htons
#define CSPNET_HTONL                   htonl
#define CSPNET_CONNECT                 connect
#define CSPNET_INET_ADDR               inet_addr
#define CSPNET_SOCKET                  socket
#define CSPNET_SETSOCKOPT              setsockopt
#define CSPNET_GETSOCKOPT              getsockopt
#define CSPNET_SELECT                  select
#define CSPNET_RECV                    recv
#define CSPNET_SEND                    send
#define CSPNET_SHUTDOWN                shutdown
#define CSPNET_BIND                    bind

#define CSPNET_FD_ISSET(fd, set)       FD_ISSET(fd, set)

#endif /* #ifdef CSP_WINSOCK2 */


typedef struct tagCSPSOCK {

   short                         sock;
   short                         load_attempted;
   short                         ipv6;
   short                         wsastartup;
   short                         winsock;

#ifdef _WIN32

   WSADATA                       wsadata;
   HINSTANCE                     h_sock;

#ifdef CSP_WINSOCK2

   LPFN_WSASOCKET                p_WSASocket;
   LPFN_WSAGETLASTERROR          p_WSAGetLastError; 
   LPFN_WSASTARTUP               p_WSAStartup;
   LPFN_WSACLEANUP               p_WSACleanup;
   LPFN_WSAFDISSET               p_WSAFDIsSet;
   LPFN_WSARECV                  p_WSARecv;
   LPFN_WSASEND                  p_WSASend;
   LPFN_CLOSESOCKET              p_closesocket;
   LPFN_GETHOSTBYNAME            p_gethostbyname;

#if defined(CSP_IPV6)
   LPFN_GETADDRINFO              p_getaddrinfo;
   LPFN_FREEADDRINFO             p_freeaddrinfo;
#else
   LPVOID                        p_getaddrinfo;
   LPVOID                        p_freeaddrinfo;
#endif

   LPFN_HTONS                    p_htons;
   LPFN_HTONL                    p_htonl;
   LPFN_CONNECT                  p_connect;
   LPFN_INET_ADDR                p_inet_addr;
   LPFN_SOCKET                   p_socket;
   LPFN_SETSOCKOPT               p_setsockopt;
   LPFN_GETSOCKOPT               p_getsockopt;
   LPFN_SELECT                   p_select;
   LPFN_RECV                     p_recv;
   LPFN_SEND                     p_send;
   LPFN_SHUTDOWN                 p_shutdown;
   LPFN_BIND                     p_bind;

#endif
#endif

} CSPSOCK, * LPCSPSOCK;


CSPSOCK csp_sock = {0, 0,  0,  0, 0};

typedef struct csp_config {
   int     cmode;                /* Environment to which record applies (directory,  */
                                 /* server, or combination).                         */
#define CONFIG_MODE_SERVER    1
#define CONFIG_MODE_DIRECTORY 2
#define CONFIG_MODE_COMBO     3  /* Shouldn't ever happen.                           */

   int     local;                /* Boolean: was "Example" directive declared here?  */
   int     congenital;           /* Boolean: did we inherit an "Example"?            */
   short   csp_enabled;
   short   auth_csp_enabled;
   char    auth_csp_enable[8];
   char    auth_csp_class[128];
   char    csp_file_types[128];
   int     csp_maxcon;
} csp_config;



/*
 * Declare ourselves so the configuration routines can find and know us.
 * We'll fill it in at the end of the module.
 */

/* CMT1226 */
static const char *cspuser = "cspadmin";
module AP_MODULE_DECLARE_DATA csp_module;

#ifdef _WIN32
static WORD VersionRequested;
#define CSP_GET_LAST_ERROR CSPNET_WSAGETLASTERROR
#else
extern int errno;
#define CSP_GET_LAST_ERROR errno
#endif


static char *CgiEnvVars[] =  {"AUTH_PASSWORD",           /*  0 */
                              "AUTH_TYPE",               /*  1 */
                              "REMOTE_ADDR",             /*  2 */
                              "REMOTE_HOST",             /*  3 */
                              "REMOTE_USER",             /*  4 */
                              "HTTP_USER_AGENT",         /*  5 */
                              "SERVER_PROTOCOL",         /*  6 */
                              "SERVER_SOFTWARE",         /*  7 */
                              "SERVER_NAME",             /*  8 */
                              "GATEWAY_INTERFACE",       /*  9 */
                              "SERVER_PORT",             /* 10 */
                              "REMOTE_IDENT",            /* 11 */
                              "HTTP_ACCEPT",             /* 12 */
                              "HTTP_REFERER",            /* 13 */
                              "PATH_TRANSLATED",         /* 14 */
                              "CONTENT_TYPE",            /* 15 */
                              "HTTP_AUTHORIZATION",      /* 16 */
                              "HTTP_COOKIE",             /* 17 */
                              "HTTPS",                   /* 18 */
                              "SERVER_PORT_SECURE",      /* 19 */
                              "REQUEST_METHOD",          /* 20 */
                              "HTTP_SOAPACTION",         /* 21 */
                              "HTTP_ACCEPT_CHARSET",     /* 22 */
                              "HTTP_ACCEPT_LANGUAGE",    /* 23 */
                              "CONTENT_LENGTH",          /* 24 */
                              "SCRIPT_NAME",             /* 25 */
                              "QUERY_STRING",            /* 26 */
                              "URL",                     /* 27 */
                              "DOCUMENT_ROOT",           /* 28 */
                              "HTTP_X_UP_SUBNO",         /* 29 */
                              "CSP_MODULE_TYPE",         /* 30 */
                              "CSP_MODULE_BUILD",        /* 31 */
                              "ALL_ENV",                 /* 32 */
                              NULL};

#define CSP_MAX_CGIS          4
static char *CgiEnvVarsS[] = {"AUTH_PASSWORD",           /*  0 */
                              "SCRIPT_NAME",             /*  1 */
                              "PATH_TRANSLATED",         /*  2 */
                              "HTTP_AUTHORIZATION",      /*  3 */
                              "CSP_MODULE_TYPE",         /*  4 */
                              "CSP_MODULE_BUILD",        /*  5 */
                              "CSP_SERVER_PORT_LOCAL",   /*  6 */
                              NULL};


typedef struct tagCSPIFC {
   short    context;
   short    defined;
   void     *p1;
   void     *p2;
   void     *p3;
} CSPIFC, *LPCSPIFC;


typedef struct tagMEMOBJ {
   int      size;
   int      curr_size;
   int      incr_size;
   char *   lp_buffer;
} MEMOBJ, *LPMEMOBJ;


#define CSPCON_SEND              0
#define CSPCON_SEND_WITH_MARGINS 1
#define CSPCON_SEND_WITH_EOF     2

#define CSPCON_STATUS_FREE       0
#define CSPCON_STATUS_INUSE      1
#define CSPCON_CON_STATUS_DSCON  0
#define CSPCON_CON_STATUS_CON    1

#define CSPCON_CLOSE_SOFT        0 /* Reuse - keep connection alive, keep memory */
#define CSPCON_CLOSE_SOFT_DSCON  1 /* Close connection, keep memory */
#define CSPCON_CLOSE_HARD        2 /* Close connection, release memory */

#define CSPCON_FREE_SPACE(a)     (a->buffer_size - (a->buffer_ptr + a->buffer_curr_size + a->buffer_tail))
#define CSPCON_ADDR_END(a)       (a->buffer + (a->buffer_ptr + a->buffer_curr_size))


typedef struct tagCSPCON {
   int            cspnsd_build;
   short          status;
   short          con_status;
#ifdef _WIN32
   WSADATA        wsadata;
   SOCKET         sockfd;
#else
   int            sockfd;
#endif
   char           ip_address[32];
   int            port;
   unsigned int   buffer_size;
   unsigned int   buffer_ptr;
   unsigned int   buffer_tail;
   unsigned int   buffer_curr_size;
   unsigned char  buffer[CACHE_BUFFER + 32];
} CSPCON, *LPCSPCON;


typedef struct tagRCB {
   int               chndle;
   LPCSPCON          lp_cspcon;
   char              ip_address[32];
   int               port;
   char              error[256];
   char              error_redir[256];
   request_rec    *  r;
   char           *  lp_method;
   char              file[64];
   FILE           *  fp;
   LPMEMOBJ          lp_cgievar;
   short             csp_form;
   short             debug;
   short             soap;
   short             chunked;
   short             request_chunked;
   short             request_header_sent;
   short             request_chunk_no;
   short             ws_headers;
   short             context;
   csp_config     *  sconf;
   csp_config     *  dconf;
   short             clen_supplied;
   unsigned long     clen;
   unsigned long     rlen;
   unsigned int      hlen;
   int               dlen;

   int               ws_buffer_ptr;
   int               ws_buffer_size;
   unsigned char  *  ws_buffer;

   int               open_status;
   int               send_no;

   LPMEMOBJ          lp_trans_buffer;

   short             eod;

   MEMOBJ            data;
   LPMEMOBJ          lp_data;

   char              debug_buffer[256];
   char              debug_header[256];

   unsigned long     ap_timeout;

} RCB, *LPRCB;

static long                   request_no        = 0;
static int                    csp_maxcon        = CSP_MAXCON;
static int                    csp_module_build  = CSP_MODULE_BUILD;
static CSPCON **              CSPCONTable       = NULL;


#if APR_HAS_THREADS || defined(DOXYGEN)
#define CSP_USE_THREADS       1
#endif

#if CSP_USE_THREADS
static apr_thread_mutex_t *   cspcon_lock       = NULL;
#endif

static apr_status_t  csp_child_exit    (void *data);
static const char *  csp_cmd           (cmd_parms *cmd, void *dconf, const char *args);


int         cspCheckFileType           (RCB *pRCB, char *type);
int         cspGetConfiguration        (RCB *pRCB);
int         cspOpenConnection          (RCB *pRCB, short context);
int         cspOpenConnectionEx        (RCB *pRCB, short context);
int         cspCloseConnection         (RCB *pRCB, short context);
int         cspCloseConnectionEx       (RCB *pRCB, short context);
int         cspTestConnection          (RCB *pRCB, short context);
int         cspSendDataToNSD           (RCB *pRCB, unsigned char *data, int data_size, short context);
int         cspSendDataToNSDEx         (RCB *pRCB, unsigned char *data, int data_size, short context);
int         cspReceiveDataFromNSD      (RCB *pRCB, unsigned char *data, int data_size);
int         cspSendResponseHeader      (RCB *pRCB, char *header, short keepalive, short *ws_headers, short context);
int         cspReturnError             (RCB *pRCB, char *error);
int         cspReturnAuthorization     (RCB *pRCB);
int         cspReturnRequestBlock      (RCB *pRCB, LPMEMOBJ lp_trans_buffer);
int         cspWriteString             (RCB *pRCB, char *buffer, short context);
int         cspWriteBuffer             (RCB *pRCB, void *buffer, int size, short context);
int         cspServerVariable          (void *rec, const char *key, const char *value);
int         cspGetServerVariable       (RCB *pRCB, char *VariableName, LPMEMOBJ lp_cgievar);
int         cspGetReqVars              (RCB *pRCB, LPMEMOBJ lp_cgievar);
int         cspMemInit                 (LPMEMOBJ lp_mem_obj, int size, int incr_size);
int         cspMemFree                 (LPMEMOBJ lp_mem_obj);
int         cspMemCpy                  (LPMEMOBJ lp_mem_obj, char *buffer, int buffer_len);
int         cspMemCat                  (LPMEMOBJ lp_mem_obj, char *buffer, int buffer_len);
int         cspLCase                   (char *string);
int         cspLogEvent                (char *event, char *title);
int         cspLog                     (RCB *pRCB, char *buffer, int size);
int         cspLoadNet                 (int context);
int         cspUnLoadNet               (int context);


/* Process configuration directives (in httpd.conf) related to this module */



static const char *csp_cmd(cmd_parms *cmd, void *dconf, const char *args)

{
   int n;
   short context;
   char *pname;
   char buffer1[64], buffer2[256];
   csp_config *conf;

    /*
     * Determine from our context into which record to put the entry.
     * cmd->path == NULL means we're in server-wide context; otherwise,
     * we're dealing with a per-directory setting.
     */

   if (cmd->path == NULL) {
      context = 0;
      conf = (csp_config *) CSP_GET_MODULE_CONFIG(cmd->server->module_config, &csp_module);
   }
   else {
      context = 1;
      conf = (csp_config *) dconf;
   }

   pname = (char *) cmd->cmd->name;
   if (!pname || !args)
      return NULL;

   strncpy(buffer1, pname, 32);
   buffer1[32] = '\0';
   cspLCase(buffer1);

   if (cmd->server->is_virtual) {   /* DP-404343 */
      ap_log_error(APLOG_MARK, APLOG_WARNING, OK, NULL, "Apache Configuration: CSP directive '%s' detected in VirtualHost, only supported at default server level", buffer1);
   }

   if (!strcmp(buffer1, "authcspenable")) {
      strncpy(buffer2, args, 7);
      buffer2[7] = '\0';
      cspLCase(buffer2);
      strcpy(conf->auth_csp_enable, buffer2);
      if (!strcmp(buffer2, "on"))
         conf->auth_csp_enabled = 1;
   }

   if (!strcmp(buffer1, "authcspclass")) {
      strncpy(buffer2, args, 127);
      buffer2[127] = '\0';
      strcpy(conf->auth_csp_class, buffer2);
   }

   if (!strcmp(buffer1, "cspfiletypes")) {
      strcpy(buffer2, ".");
      strncpy(buffer2 + 1, args, 126);
      buffer2[126] = '\0';
      strcat(buffer2, ".");
      for (n = 0; buffer2[n]; n ++) {
         if (buffer2[n] == ' ')
            buffer2[n] = '.';
      }
      cspLCase(buffer2);
      strcpy(conf->csp_file_types, buffer2);

   }

   if (!strcmp(buffer1, "csp")) {
      strncpy(buffer2, args, 7);
      buffer2[7] = '\0';
      cspLCase(buffer2);
      if (!strcmp(buffer2, "on"))
         conf->csp_enabled = 1;
   }

   if (!strcmp(buffer1, "cspmaxpoolednsdconnections") && context == 0) {
      strncpy(buffer2, args, 7);
      buffer2[7] = '\0';
      conf->csp_maxcon = (int) strtol(buffer2, NULL, 10);
      if (conf->csp_maxcon < -1 || conf->csp_maxcon > 1024)
         conf->csp_maxcon = CSP_MAXCON;
   }

   return NULL;
}



/* Main content handler for CSP requests */


static int csp_handler(request_rec *r)
{
   short phase;
   int retval, seen_eos;
   long n1;
   short nsd_gone, client_gone, ws_error, con_close, con_ka, keepalive, trans_enc_chunked;
   unsigned int n;
   unsigned char buffer[CSP_TEMP_BUFFER];
   unsigned char *lp_content, *lp_base, *lp_base1, *lp_end;
   RCB RCB;
   LPRCB pRCB;
   MEMOBJ cgievar, trans_buffer;
   LPMEMOBJ lp_cgievar, lp_trans_buffer;
   CSPIFC cspifc;
   table *e = r->subprocess_env;
   time_t time_start, time_now, time_diff;

   apr_bucket_brigade *bb = NULL;
   apr_status_t rv = 0;
   conn_rec *c = r->connection;
   struct ap_filter_t *cur = NULL;

   phase = 0;

   pRCB = &RCB;
   pRCB->r = r;

   pRCB->debug_header[0] = '\0';

   pRCB->context = 0;
   pRCB->csp_form = 0;
   pRCB->soap = 0;
   pRCB->clen = 0;
   pRCB->send_no = 0;
   pRCB->chunked = 0;
   pRCB->clen_supplied = 0;
   pRCB->request_chunk_no = 0;
   pRCB->request_header_sent = 0;

   pRCB->lp_cspcon = NULL;

   pRCB->lp_trans_buffer = NULL;

   pRCB->ws_buffer = NULL;
   pRCB->ws_buffer_size = 0;
   pRCB->ws_buffer_ptr = 0; /* CMT800 */

   nsd_gone = 0;
   client_gone = 0;
   ws_error = 0; /* CMT819 */

   time_start = time(NULL);

   pRCB->dconf = (csp_config *) CSP_GET_MODULE_CONFIG(r->per_dir_config, &csp_module);
   pRCB->sconf = (csp_config *) CSP_GET_MODULE_CONFIG(r->server->module_config, &csp_module);

/*
   ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "pRCB->sconf->csp_enabled=%d; pRCB->dconf->csp_enabled=%d; uri=%s; timeout=%d;", pRCB->sconf->csp_enabled, pRCB->dconf->csp_enabled, pRCB->r->uri, pRCB->r->server->timeout/1000);
*/

   if (!r)
      return DECLINED;

   if (!r->uri)
      return DECLINED;
   n = (unsigned int) strlen(r->uri);
   if (!n)
      return DECLINED;
   n1 = 0;

/*
   if (n > 1024) {
      ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, r, "mod_csp: Oversize request rejected");
      return DECLINED;
   }
*/

   for (n --; n > 0; n --) {

      if (r->uri[n] == '.') {
         for (n ++; r->uri[n]; n ++) {
            if (r->uri[n] == '/' || r->uri[n] == '\\')
               break;
            buffer[n1 ++] = r->uri[n];
            if (n1 > (CSP_TEMP_BUFFER - 3)) /* CMT781 */
               break;
         }
         break;
      }
   }

   buffer[n1] = '\0';

   if (pRCB->dconf->csp_enabled == 0) {

      if (!n1)
         return DECLINED;

      cspLCase((char *) buffer);

      if (strcmp(r->handler, CSP_MAGIC_TYPE1) && strcmp(r->handler, CSP_MAGIC_TYPE2) && strcmp(r->handler, "csp-handler-sa")) {

         if (!cspCheckFileType(pRCB, (char *) buffer)) {

            short ok;
            char *p;

            ok = 0;

            p = strstr(r->uri, ".");
            if (p) {
               strncpy((char *) buffer, p + 1, 3);
               buffer[3] = '\0'; 
               cspLCase((char *) buffer);
               if (cspCheckFileType(pRCB, (char *) buffer))
                  ok = 1;
            }

            if (!ok) {
/*
               ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, r, "mod_csp: Bad request: %s", r->uri);
*/
               return DECLINED;
            }
         }
      }
   }

   if (!r->method) {
/*
      ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, r, "mod_csp: Bad method for request: %s", r->uri);
*/
      return DECLINED;
   }

   if (strlen(r->method) > 16) {
/*
      ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, r, "mod_csp: Oversize method (> 16 Bytes) for request: %s", r->uri);
*/
      return DECLINED;
   }

   lp_cgievar = &cgievar;
   lp_trans_buffer = &trans_buffer;

   pRCB->lp_data = &(pRCB->data);
   cspMemInit(pRCB->lp_data, 8192, 8182);

   con_close = 0, con_ka = 0, keepalive = 0, trans_enc_chunked = 0;
   pRCB->ws_headers = 0;
   request_no ++;

/*
   if ((retval = CSP_SETUP_CLIENT_BLOCK(r, REQUEST_CHUNKED_ERROR)))
      return retval;
*/

   if ((retval = CSP_SETUP_CLIENT_BLOCK(r, REQUEST_CHUNKED_DECHUNK)))
      return retval;

/*
   if ((retval = CSP_SETUP_CLIENT_BLOCK(r, REQUEST_CHUNKED_PASS)))
      return retval;
*/

   CSP_ADD_COMMON_VARS(r);
   CSP_ADD_CGI_VARS(r);

   pRCB->lp_method = (char *) r->method;
   pRCB->ap_timeout = 0;
   if (pRCB->r && pRCB->r->server) {
      pRCB->ap_timeout = (unsigned long) (pRCB->r->server->timeout / 1000);
   }
   if (pRCB->ap_timeout < 3000)
      pRCB->ap_timeout = CSP_DEFAULT_AP_TIMEOUT;

   cspMemInit(lp_cgievar, 256, 256);
   cspMemInit(lp_trans_buffer, 2048, 256);

   pRCB->lp_cgievar = lp_cgievar;

   cspGetConfiguration(pRCB);
   cspGetReqVars(pRCB, lp_cgievar);

   cspMemCpy(lp_trans_buffer, "#########\r", 10);
   for (n = 0; CgiEnvVarsS[n]; n ++) {

      n1 = cspGetServerVariable(pRCB, CgiEnvVarsS[n], lp_cgievar);

      if (!strcmp(CgiEnvVarsS[n], "SCRIPT_NAME")) {

         strncpy((char *) buffer, lp_cgievar->lp_buffer, 200);
         buffer[200] = '\0';
         cspLCase((char *) buffer);

         if (strstr((char *) buffer, ".csp") || strstr((char *) buffer, ".cls")) {
            pRCB->csp_form = 1;
         }

      }

      if (n1 > -1) {

         if (n == 15 && strstr(lp_cgievar->lp_buffer, "/xml"))
            pRCB->soap = 1;
         if (n == 21)
            pRCB->soap = 1;

         cspMemCat(lp_trans_buffer, CgiEnvVarsS[n], strlen(CgiEnvVarsS[n]));
         cspMemCat(lp_trans_buffer, "=", 1);
         cspMemCat(lp_trans_buffer, lp_cgievar->lp_buffer, lp_cgievar->curr_size);
         cspMemCat(lp_trans_buffer, "\r", 1);
      }
   }

   cspifc.context = 0;
   cspifc.p1 = (void *) pRCB;
   cspifc.p2 = (void *) lp_trans_buffer;

   CSP_TABLE_DO(cspServerVariable, (void *) &cspifc, e, NULL);

   sprintf((char *) buffer, "%d", (lp_trans_buffer->curr_size - 10));
   strncpy(lp_trans_buffer->lp_buffer, (char *) buffer, strlen((char *) buffer));


#ifdef CSP_DEBUG
   if (strstr(lp_trans_buffer->lp_buffer, "cmunt~cmunt") || strstr(lp_trans_buffer->lp_buffer, "cmunt=cmunt")) {
      cspReturnRequestBlock(pRCB, lp_trans_buffer);
      goto csp_handler_exit2;
   }
#endif

   pRCB->open_status = cspOpenConnection(pRCB, 0);

/*
   ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp: GetConnection: pRCB->open_status=%d; pRCB->chndle=%d; header_size=%d", pRCB->open_status, pRCB->chndle, lp_trans_buffer->curr_size);
*/

   if (!pRCB->open_status) {
      cspReturnError(pRCB, pRCB->error);
      goto csp_handler_exit2;
   }

   pRCB->lp_trans_buffer = lp_trans_buffer;

   pRCB->lp_cspcon->buffer_size = CACHE_BUFFER;
   pRCB->lp_cspcon->buffer_curr_size = 0;
   pRCB->lp_cspcon->buffer_ptr = 0;
   pRCB->lp_cspcon->buffer_tail = 0;
   pRCB->lp_cspcon->buffer[0] = '\0';

   pRCB->lp_cspcon->buffer_ptr += (lp_trans_buffer->curr_size + 8);

   if (pRCB->request_chunked) {
      pRCB->lp_cspcon->buffer_ptr += 16;
      pRCB->lp_cspcon->buffer_tail += 16;
   }

   pRCB->rlen = 0;

   if (pRCB->clen || pRCB->request_chunked) {

      int n;
      const char * data;
      apr_size_t len;

      bb = apr_brigade_create(r->pool, r->connection->bucket_alloc);
      seen_eos = 0;

      do {
         apr_bucket *bucket;

         rv = ap_get_brigade(r->input_filters, bb, AP_MODE_READBYTES, APR_BLOCK_READ, HUGE_STRING_LEN);

         if (rv != APR_SUCCESS) {
            client_gone = 1;
            ws_error = 1; /* CMT819 */
            break;
         }

         for (bucket = APR_BRIGADE_FIRST(bb); bucket != APR_BRIGADE_SENTINEL(bb); bucket = APR_BUCKET_NEXT(bucket)) {

            if (APR_BUCKET_IS_EOS(bucket)) {
               seen_eos = 1;
               break;
            }

            /* We can't do much with this. */
            if (APR_BUCKET_IS_FLUSH(bucket)) {
               continue;
            }

            /* If the NSD stopped, we still must read to EOS. */
            if (nsd_gone) {
               continue;
            }

            /* read */
            apr_bucket_read(bucket, &data, &len, APR_BLOCK_READ);

            if (len < (apr_size_t) CSPCON_FREE_SPACE(pRCB->lp_cspcon)) {

               memcpy((void *) CSPCON_ADDR_END(pRCB->lp_cspcon), (void *) data, len);
               pRCB->lp_cspcon->buffer_curr_size += len;
            }
            else {
               if (pRCB->lp_cspcon->buffer_curr_size) {
                  n = cspSendDataToNSD(pRCB, NULL, pRCB->lp_cspcon->buffer_curr_size, CSPCON_SEND_WITH_MARGINS);
                  if (n < 0) {
                     nsd_gone = 1;
                  }
                  pRCB->lp_cspcon->buffer_curr_size = 0;
                  pRCB->lp_cspcon->buffer_ptr = 0;
                  if (pRCB->request_chunked)
                     pRCB->lp_cspcon->buffer_ptr += 16;
               }
               if (len > CSPCON_FREE_SPACE(pRCB->lp_cspcon)) {
                  n = cspSendDataToNSD(pRCB, (unsigned char *) data, len, CSPCON_SEND);
               }
               else {
                  memcpy((void *) CSPCON_ADDR_END(pRCB->lp_cspcon), (void *) data, len);
                  pRCB->lp_cspcon->buffer_curr_size += len;
               }
            }
            pRCB->rlen += len;

            if (!pRCB->request_chunked && pRCB->rlen >= pRCB->clen) {
               seen_eos = 1;
               break;
            }

         }
         apr_brigade_cleanup(bb);

      } while (!seen_eos);
   }

   if (ws_error) { /* CMT819 */
      ap_log_rerror(APLOG_MARK, APLOG_ERR, rv,  pRCB->r, "Error reading request entity data");
      goto csp_handler_exit1;
   }

   if (!nsd_gone) {
      int n;
      n = cspSendDataToNSD(pRCB, NULL, pRCB->lp_cspcon->buffer_curr_size, CSPCON_SEND_WITH_EOF);
      if (n < 0) {
         nsd_gone = 1;
      }
   }

   if (!pRCB->open_status) {
      cspReturnError(pRCB, pRCB->error);
      goto csp_handler_exit2;
   }
   if (nsd_gone) {
      strcpy(pRCB->error, "Transmission of request data to Cache interrupted");
      cspReturnError(pRCB, pRCB->error);
      goto csp_handler_exit1;
   }

/*
   pRCB->clen = 0;
   pRCB->rlen = 0;
   pRCB->lp_cspcon->buffer_ptr = 0;
   pRCB->lp_cspcon->buffer_size = CACHE_BUFFER;
   pRCB->lp_cspcon->buffer[0] = '\0';
*/

csp_handler_retry:

   pRCB->eod = 0;
   lp_content = NULL;
   pRCB->dlen = 0;
   pRCB->hlen = 0;

   for (;;) {
      pRCB->context = 1;
      sprintf(pRCB->debug_buffer, "ctx=%d; len=%d; get=%d", pRCB->context, pRCB->dlen, (8000 - pRCB->dlen));
      retval = cspReceiveDataFromNSD(pRCB, (unsigned char *) buffer + pRCB->dlen, 8000 - pRCB->dlen);
      if (retval < 1) {
         if (retval < 0)
            nsd_gone = 1;
         break;
      }
      pRCB->dlen += retval;
      buffer[pRCB->dlen] = '\0';
      lp_content = (unsigned char *) strstr((char *) buffer, "\r\n\r\n");
      if (lp_content || pRCB->dlen == 8000)
         break;
   }

   strncpy(pRCB->debug_header, (char *) buffer, 250);
   pRCB->debug_header[250] = '\0';

/*
cspLogEvent(buffer, "cmcmcm header");
*/
   if (nsd_gone) {
      if (pRCB->open_status == 2 && pRCB->send_no == 1) {

         cspCloseConnectionEx(pRCB, CSPCON_CLOSE_SOFT_DSCON);
         pRCB->open_status = cspOpenConnectionEx(pRCB, 0);
         if (pRCB->open_status) {
            int n;

            n = cspSendDataToNSDEx(pRCB, pRCB->lp_cspcon->buffer + pRCB->lp_cspcon->buffer_ptr, pRCB->lp_cspcon->buffer_curr_size, CSPCON_SEND_WITH_EOF);
            if (n < 0) {
               nsd_gone = 1;
            }
            else {
               nsd_gone = 0;
               goto csp_handler_retry;
            }
         }
         else {
            goto csp_handler_exit1;
         }
      }
   }
   if (nsd_gone) {
      strcpy(pRCB->error, "Response not received from Cache");
      cspReturnError(pRCB, pRCB->error);
      goto csp_handler_exit1;
   }

   pRCB->clen = 0;
   pRCB->rlen = 0;
   pRCB->lp_cspcon->buffer_ptr = 0;
   pRCB->lp_cspcon->buffer_size = CACHE_BUFFER;
   pRCB->lp_cspcon->buffer[0] = '\0';
   memcpy((void *) pRCB->lp_cspcon->buffer, (void *) buffer, pRCB->dlen);
   pRCB->lp_cspcon->buffer[pRCB->dlen] = '\0';
   lp_content = (unsigned char *) strstr((char *) pRCB->lp_cspcon->buffer, "\r\n\r\n");



/*
   ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp: Header read: pRCB->chndle=%d; nsd_gone=%d; client_gone=%d; len=%d", pRCB->chndle, nsd_gone, client_gone, len);
*/

   pRCB->lp_cspcon->buffer[pRCB->dlen] = '\0';
   pRCB->lp_cspcon->buffer_ptr = pRCB->dlen;

   lp_base = pRCB->lp_cspcon->buffer;
   lp_base1 = lp_base;
   pRCB->rlen = 0;

   if (lp_content && !strncmp((char *) pRCB->lp_cspcon->buffer, "HTTP/", 5)) {

      int n;
      double version;
      unsigned char chr;
      unsigned char *p, *p1, *pv;
      char head[256];


      lp_content += 4;
      chr = *lp_content;
      *(lp_content) = '\0';
      pRCB->hlen = strlen((char *) pRCB->lp_cspcon->buffer);
/*
      ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp: Header: len=%d; header=%s", hlen, pRCB->lp_cspcon->buffer);
*/

      con_close = 0, con_ka = 0, keepalive = 0, trans_enc_chunked = 0;
      pRCB->ws_headers = 0;
      version = 1.1;

      for (p = pRCB->lp_cspcon->buffer, n = 0; ; n ++) {
         p1 = (unsigned char *) strstr((char *) p, "\r\n");
         if (!p1)
            break;
         *p1 = '\0';
         if (!strlen((char *) p)) {
            *p1 = '\r';
            break;
         }

         if (!n) {
            if (strstr((char *) p, "/1.0"))
               version = 1.0;
         }
         else {
            strncpy(head, (char *) p, 250);
            head[250] = '\0';

            cspLCase(head);

            if (strstr(head, "connection: close"))
               con_close = 1;
            else if (strstr(head, "connection: keep-alive"))
               con_ka = 1;
            else if (strstr(head, "csp-transfer-encoding: chunked")) {
               pRCB->chunked = 1;
            }
            else if (strstr(head, "transfer-encoding: chunked")) {
               trans_enc_chunked = 1;
               pRCB->chunked = 1;
            }
            else if ((pv = (unsigned char *) strstr(head, "content-length: "))) {
               pRCB->clen_supplied = 1;
               pRCB->clen = (unsigned long) strtol((char *) (pv + 16), NULL, 10);
            }
            else if (strstr(head, "csp-nph: false"))  
               pRCB->ws_headers = 1;
         }

         *p1 = '\r';

         p = p1 + 2;
      }

      if (version == 1.1 && !con_close) {
         keepalive = 1;
         pRCB->ws_headers = 1;
      }
      if (version == 1.0 && con_ka) {
         keepalive = 1;
         pRCB->ws_headers = 1;
      }

      cspSendResponseHeader(pRCB, (char *) pRCB->lp_cspcon->buffer, keepalive, &pRCB->ws_headers, 1);

      pRCB->rlen = (pRCB->dlen - pRCB->hlen);

      if (pRCB->ws_headers) {
         lp_base1 = lp_content;
         pRCB->dlen -= pRCB->hlen;
      }

      *lp_content = chr;
   }
   else {

      lp_content = lp_base1;

      ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp (%d.%d): no HTTP header (rlen=%u; content=%s)", CSP_MODULE_BUILD, CSP_ADHOC_BUILD, pRCB->dlen, pRCB->lp_cspcon->buffer);

      /* get rid of all filters up through protocol...  since we
       * haven't parsed off the headers, there is no way they can
       * work
       */

      cur = r->proto_output_filters;
      while (cur && cur->frec->ftype < AP_FTYPE_CONNECTION) {
         cur = cur->next;
      }
      r->output_filters = r->proto_output_filters = cur;

      pRCB->rlen = pRCB->dlen;
      cspWriteBuffer(pRCB, pRCB->lp_cspcon->buffer, pRCB->dlen, 0);
      pRCB->dlen = 0;
   }

/*
   ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp: Header processed: pRCB->chndle=%d; nsd_gone=%d; client_gone=%d; pRCB->chunked=%d; trans_enc_chunked=%d; ws_headers=%d; rlen=%d; len=%d; hlen=%d", pRCB->chndle, nsd_gone, client_gone, pRCB->chunked, trans_enc_chunked, ws_headers, rlen, len, hlen);
*/

   if (client_gone)
      goto csp_handler_exit1;

   /*
      len > 0  : len undispatched Bytes in output buffer
   */
/*
{
   char buffer[256];
   sprintf(buffer, "chunked=%d; clen_supplied=%d; clen=%d;", pRCB->chunked, pRCB->clen_supplied, pRCB->clen);
   cspLogEvent(buffer, "cmcmcm status");
}
*/

   if (pRCB->clen_supplied)
      pRCB->chunked = 0;

   if (pRCB->chunked || (pRCB->clen_supplied && pRCB->clen) || pRCB->dlen > 0) {

      if (csp_module_build >= 7 && (pRCB->chunked || (pRCB->clen_supplied && pRCB->clen))) {

         if (pRCB->chunked) {
            short eod;
            char chunk_head[32];
            unsigned char *p, *p1, *p_chunk_header, *p_commit;
            unsigned int n1, n2, avail, chunk_size, chunk_head_size, tail;

            /* CMT805 */
            /*
            Chunked content is read into and dispatched from the same buffer.
            The object is to get the data to the client in the appropriate form with as little copying and memory usage as possible.
            This will give the best performance.

            Input/output buffer: lp_base = pRCB->lp_cspcon->buffer:

            The following variables point into the I/O buffer.
               lp_content     : The place where the POSTED content starts after the headers.
               lp_base1       : The point from which data is dispatched from the client.
                                For the first buffer read, this will be either the beginning of the buffer (Gateway to dispatch HTTP headers), or:
                                lp_content (Web Server to dispatch HTTP headers)

               p_chunk_header : current chunk header
               p_commit       : point up to which buffer is committed for dispatch to client
               lp_end         : End of current data buffer

            */

            *chunk_head = '\0';
            chunk_head_size = 0;
            chunk_size = 0;
            p_chunk_header = lp_content;
            p_commit = p_chunk_header;
            lp_end = (lp_base + pRCB->lp_cspcon->buffer_ptr);
            eod = 0;
/*
            ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp: start: (lp_content-lp_base)=%d; (lp_content-lp_base1)=%d; (lp_end - lp-base)=%d; pRCB->lp_cspcon->buffer_ptr=%d;", (lp_content-lp_base), (lp_content-lp_base1), (lp_end - lp_base), pRCB->lp_cspcon->buffer_ptr);
*/

            for (;;) {

               if (!chunk_size) { /* No more chunk data to process - get next chunk header */

                  p = NULL;
                  p1 = NULL;

                  for (n = 0; n < 20; n ++) {

                     avail = lp_end - p_chunk_header;

                     if (avail > 0) {
                        p = NULL;
                        p1 = NULL;

                        for (n1 = 0; n1 < avail; n1 ++) {

                           if (p_chunk_header[n1] != '\r' && p_chunk_header[n1] != '\n') {
                              p = (p_chunk_header + n1); /* start of chunk header */
                              break;
                           }
                        }
                        if (p) {
                           for (n2 = n1; n2 < avail; n2 ++) {
                              if (p_chunk_header[n2] == '\n' && p_chunk_header[n2 - 1] == '\r') {
                                 p1 = p_chunk_header + (n2 - 1); /* end of chunk header */
                                 break;
                              }
                              if (!strrchr("0123456789abcdefABCDEF\r\n", (int) p_chunk_header[n2])) {
                                 break;
                              }
                           }
                        }
                        if (p1) {
                           break; /* exit with chunk header */
                        }
                     }

                     if (avail > 30) { /* can't find valid chunk header in 30 Bytes */

                        ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp (%d.%d): no chunk (code=-1; request_no=%lu; rlen=%lu; clen=%lu; avail=%u; chunk_size=%u; chunk_head_size=%u; chunk_head=%s)", CSP_MODULE_BUILD, CSP_ADHOC_BUILD, request_no, pRCB->rlen, pRCB->clen, avail, chunk_size, chunk_head_size, chunk_head);
                        break;
                     }

                     pRCB->context = 2;

                     sprintf(pRCB->debug_buffer, "ctx=%d; buffer_size=%d; offs_base=%ld; offs_commit=%ld; offs_end=%ld; chunk_size=%d; chunk_header=%s, get=%ld", pRCB->context, pRCB->lp_cspcon->buffer_size, (long) (lp_base1 - lp_base), (long) (p_commit - lp_base), (long) (lp_end - lp_base), chunk_size, chunk_head, (long) (pRCB->lp_cspcon->buffer_size - (lp_end - pRCB->lp_cspcon->buffer)));
                     retval = cspReceiveDataFromNSD(pRCB, (unsigned char *) lp_end, pRCB->lp_cspcon->buffer_size - (lp_end - pRCB->lp_cspcon->buffer));
                     if (retval < 1) {
                        nsd_gone = 1;
                        break;
                     }
                     else {
                        lp_end += retval;
                     }
                  }

                  if (nsd_gone)
                     break;

                  if (p1) { /* valid chunk header found */

                     *p1 = '\0';

                     chunk_size = (int) strtol((char *) p, NULL, 16);
                     strncpy(chunk_head, (char *) p, 30);
                     chunk_head[30] = '\0';

                     chunk_head_size = strlen((char *) p_chunk_header) + 2;

/*
                     ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp: Chunk header: chunk_size=%d (EOD=%d) ; chunk_head_size=%d; header=%s\\r\\n; pRCB->lp_cspcon->buffer_ptr=%d; avail=%d", chunk_size, eod, chunk_head_size, p_chunk_header, pRCB->lp_cspcon->buffer_ptr, avail);
*/
                     *p1 = '\r';

                     if (!chunk_size) /* End of chunked content */
                        eod = 1;

                     if (!trans_enc_chunked) { /* Only pass chunked data if header set.  If headers are pushed through Apache it will chunk response anyway */
                        /* client doesn't want chunked response, so shuffle buffer up to overwrite the chunk header */

                        if (eod) { /* CMT808: Client doesn't want a chunked response so discard everything after the terminating zero-size chunk header */
                           chunk_head_size = (lp_end - p_chunk_header);
                        }

                        avail -= chunk_head_size;
                        memmove((void *) p_chunk_header, (void *) (p_chunk_header + chunk_head_size), avail);
                        lp_end -= chunk_head_size;
                        chunk_head_size = 0;
                     }

                     if (eod)
                        p_commit = lp_end;
                     else
                        p_commit += chunk_head_size;

                  }
                  else { /* No chunked header in 30 Bytes of data */

                     /* Protocol obviously violated: Flush buffer, revert to non chunked mode and hope server closes connection at end of response */

                        ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp (%d.%d): bad chunk header: request_no=%lu; size=%u; response=%s", CSP_MODULE_BUILD, CSP_ADHOC_BUILD, request_no, pRCB->lp_data->curr_size, pRCB->lp_data->lp_buffer);
                     if (!cspWriteBuffer(pRCB, p_chunk_header, avail, 0))
                        client_gone = 1;

                     pRCB->chunked = 0;
                     break;
                  }
               }

               if (chunk_size) { /* chunk (or part of a chunk) to read */

                  avail = lp_end - p_commit;

/*
                  ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp: Chunk Read: chunk_size=%d; avail=%d", chunk_size, avail);
*/

                  if (avail >= chunk_size) { /* Enough data in buffer to satisfy current chunk */
                     p_commit += chunk_size;
                     p_chunk_header = p_commit;
                     chunk_size = 0;
                     if (pRCB->lp_cspcon->buffer_size - (lp_end - pRCB->lp_cspcon->buffer) > 50) { /* More space in buffer - so process next chunk */
                        continue;
                     }
                  }
                  else { /* Increment 'commit' pointer and subtract the available data from the current chunk size */
                     chunk_size -= avail;
                     p_commit += avail;
                  }
               }


              /* Dispatch data up to the commit point */

               avail = (p_commit - lp_base1);
               tail = (lp_end - p_commit);

               /* CMT805 */
               if (avail) { /* Dispatch response data to client (if any) */
                  if (!cspWriteBuffer(pRCB, lp_base1, avail, 0)) {
                     client_gone = 1;
                     break;
                  }
               }

               if (eod) /* End of response */
                  break;

               lp_base1 = lp_base;
               p_chunk_header = lp_base1;
               lp_content = lp_base1;
               if (tail) {
                  memcpy((void *) lp_base1, (void *) p_commit, tail);
               }
               p_commit = lp_base1;
               lp_end = lp_base1 + tail;

               if (chunk_size == 0) { /* CMT805 Chunk committed and dispatched so process the next chunk header */
                  continue;
               }

               pRCB->context = 3;
               *lp_end = '\0';
               sprintf(pRCB->debug_buffer, "ctx=%d; buffer_size=%d; offs_base=%ld; offs_commit=%ld; offs_end=%ld; chunk_size=%d; chunk_header=%s, get=%ld", pRCB->context, pRCB->lp_cspcon->buffer_size, (long) (lp_base1 - lp_base), (long) (p_commit - lp_base), (long) (lp_end - lp_base), chunk_size, chunk_head, (long) (pRCB->lp_cspcon->buffer_size - (lp_end - pRCB->lp_cspcon->buffer)));
               retval = cspReceiveDataFromNSD(pRCB, (unsigned char *) lp_end, pRCB->lp_cspcon->buffer_size - (lp_end - pRCB->lp_cspcon->buffer));

               if (retval < 1) {
                  nsd_gone = 1;
                  break;
               }
               lp_end += retval;
            }

         }

         if (!pRCB->chunked && !client_gone && !nsd_gone) {

            for (;;) {
      
               if (pRCB->dlen > 0) {
                  retval = pRCB->dlen;
                  pRCB->dlen = 0;
               }
               else {
                  pRCB->context = 4;
                  sprintf(pRCB->debug_buffer, "ctx=%d; buffer_size=%d; offs_base=%ld; offs_end=%ld; get=%ld", pRCB->context, pRCB->lp_cspcon->buffer_size, (long) (lp_base1 - lp_base), (long) (lp_end - lp_base), (CACHE_BUFFER - (lp_base1 - lp_base)));
                  retval = cspReceiveDataFromNSD(pRCB, (unsigned char *) lp_base1, CACHE_BUFFER - (lp_base1 - lp_base));


                  if (retval < 1) {
                     nsd_gone = 1;
                     break;
                  }
                  else
                     pRCB->rlen += retval;
               }

               if (!cspWriteBuffer(pRCB, lp_base1, retval, 0)) {

                  client_gone = 1;
                  break;
               }
               lp_base1 = lp_base;

               /* CMT805 */
               if (pRCB->clen_supplied && pRCB->clen == 0)
                  break;
               if (pRCB->clen && pRCB->rlen == pRCB->clen) { /* Content length supplied */
                  break;
               }
            }
         }
      }

      else {

         pRCB->rlen = 0;
         lp_end = (lp_base + pRCB->lp_cspcon->buffer_ptr);

         for (;;) {
      
            if (pRCB->dlen > 0) {
               retval = pRCB->dlen;
               pRCB->dlen = 0;
            }
            else {
               pRCB->context = 5;
               sprintf(pRCB->debug_buffer, "ctx=%d; buffer_size=%d; offs_base=%ld; offs_end=%ld; get=%ld", pRCB->context, pRCB->lp_cspcon->buffer_size, (long) (lp_base1 - lp_base), (long) (lp_end - lp_base), (CACHE_BUFFER - (lp_base1 - lp_base)));
               retval = cspReceiveDataFromNSD(pRCB, (unsigned char *) lp_base1, CACHE_BUFFER - (lp_base1 - lp_base));
            }


            if (retval < 1) {
               nsd_gone = 1;
               break;
            }

            if (!cspWriteBuffer(pRCB, lp_base1, retval, 0)) {
               client_gone = 1;
               break;
            }
            lp_base1 = lp_base;

            pRCB->rlen += retval;

            /* CMT800 */
            if (pRCB->clen_supplied && pRCB->clen == 0)
               break;
            if (pRCB->clen && pRCB->rlen == pRCB->clen)
               break;
         }
      }
   }

   if (client_gone) {
      time_now = time(NULL);
      time_diff = (time_t) difftime(time_now, time_start);
/*
      ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "csp_handler: client closed the connection while awaiting a response to: %s (time elapsed: %d)", pRCB->r->uri, time_diff);
*/
   }


csp_handler_exit1:

/*
   ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp: EOD: pRCB->chndle=%d; client_gone=%d; nsd_gone=%d", pRCB->chndle, client_gone, nsd_gone);
*/

   if (pRCB->lp_cspcon->cspnsd_build < 9999) {
      n = cspCloseConnection(pRCB, CSPCON_CLOSE_HARD);
   }
   else {
      if (csp_module_build >= 7) {
         if (client_gone || nsd_gone)
            n = cspCloseConnection(pRCB, CSPCON_CLOSE_HARD);
         else
            n = cspCloseConnection(pRCB, CSPCON_CLOSE_SOFT);
      }
      else
         n = cspCloseConnection(pRCB, CSPCON_CLOSE_HARD);
   }


csp_handler_exit2:

   if (pRCB->ws_buffer) {
      if (pRCB->ws_buffer_ptr)
         cspWriteBuffer(pRCB, pRCB->ws_buffer, pRCB->ws_buffer_ptr, 1);
      free((void *) pRCB->ws_buffer);
   }

   cspMemFree(lp_cgievar);
   cspMemFree(lp_trans_buffer);
/*
   ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp: request_no=%lu; size=%lu; response=%s", request_no, pRCB->lp_data->curr_size, pRCB->lp_data->lp_buffer);
*/
   cspMemFree(pRCB->lp_data);

   if (ws_error) /* CMT819 */
      return HTTP_INTERNAL_SERVER_ERROR;
   else
      return OK;
}



/* 
 * This function is called during server initialization.  Any information
 * that needs to be recorded must be in static cells, since there's no
 * configuration record.
 *
 */


static int csp_init(apr_pool_t *pPool, apr_pool_t *pLog, apr_pool_t *pTemp, server_rec *s)
{
   char *sname = s->server_hostname;
   csp_config *sconf;

   sconf = (csp_config *) CSP_GET_MODULE_CONFIG(s->module_config, &csp_module);


   return OK;

}



/* 
 * This function is called during server initialization when a heavy-weight
 * process (such as a child) is being initialised.  As with the
 * module-initialization function, any information that needs to be recorded
 * must be in static cells, since there's no configuration record.
 *
 * There is no return value.
 */


static void csp_child_init(pool *p, server_rec *s)
{
   int n, retval;
   char *sname = s->server_hostname;
   csp_config *sconf;

   retval = 0;
   sconf = NULL;

#if CSP_MODULE_BUILD >= 7
   sconf = (csp_config *) CSP_GET_MODULE_CONFIG(s->module_config, &csp_module);
   if (sconf) {
/*
      ap_log_error(APLOG_MARK, APLOG_NOTICE, 0, NULL, "csp_child_init: csp_maxcon=%d; sconf->csp_maxcon=%d", csp_maxcon, sconf->csp_maxcon);
*/
      csp_maxcon = sconf->csp_maxcon;
      if (csp_maxcon < 0) {
         csp_maxcon = 0;
         csp_module_build = 6;
      }
   }
#else
   csp_maxcon = 0;
#endif

   CSPCONTable = NULL;
   if (csp_maxcon > 0) {

#if CSP_USE_THREADS
      if (cspcon_lock == NULL) {
         retval = apr_thread_mutex_create((apr_thread_mutex_t **)  &cspcon_lock, (unsigned int) APR_THREAD_MUTEX_DEFAULT, (apr_pool_t *)  p);
         if (retval != APR_SUCCESS) {
/*
            ap_log_error(APLOG_MARK, APLOG_NOTICE, 0, NULL, "csp_child_init: apr_thread_mutex_create failed: %d", retval);
*/
            cspcon_lock = NULL;
         }
      }
#endif

      CSPCONTable = (CSPCON **) malloc(sizeof(CSPCON *) * csp_maxcon);
      if (!CSPCONTable)
         csp_maxcon = 0;
   }

   for (n = 0; n < csp_maxcon; n ++) {
      CSPCONTable[n] = NULL;
   }


   cspLoadNet(0);

   apr_pool_cleanup_register(p, s, csp_child_exit, csp_child_exit);

   return;
}



/* 
 * This function is called when an heavy-weight process (such as a child) is
 * being run down or destroyed.  As with the child-initialization function,
 * any information that needs to be recorded must be in static cells, since
 * there's no configuration record.
 *
 */


static apr_status_t csp_child_exit(void *data)
{
   int n, retval;
   server_rec *s = data;
   char *sname = s->server_hostname;

   retval = 0;
   sname = (sname != NULL) ? sname : "";

   if (csp_maxcon > 0) {
      for (n = 0; n < csp_maxcon; n ++) {

         if (CSPCONTable[n] && CSPCONTable[n]->con_status != CSPCON_CON_STATUS_DSCON) {

#ifdef _WIN32
            CSPNET_CLOSESOCKET(CSPCONTable[n]->sockfd);
#else /* UNIX */
            close(CSPCONTable[n]->sockfd);
#endif
         }
         free((void *) CSPCONTable[n]);
         CSPCONTable[n] = NULL;
      }

      if (CSPCONTable) {
         free((void *) CSPCONTable);
         CSPCONTable = NULL;
      }
   }

   cspUnLoadNet(0);

#if CSP_USE_THREADS
   if (cspcon_lock)
      retval = apr_thread_mutex_destroy(cspcon_lock);
#endif

    return APR_SUCCESS;
}



/*
 * This function gets called to create up a per-directory configuration
 * record.  This will be called for the "default" server environment, and for
 * each directory for which the parser finds any of our directives applicable.
 * If a directory doesn't have any of our directives involved (i.e., they
 * aren't in the .htaccess file, or a <Location>, <Directory>, or related
 * block), this routine will *not* be called - the configuration for the
 * closest ancestor is used.
 *
 * The return value is a pointer to the created module-specific
 * structure.
 */

static void *csp_create_dir_config(pool *p, char *dirspec)
{
   csp_config *cfg;
   char *dname = dirspec;

   /*
    * Allocate the space for our record from the pool supplied.
    */

   cfg = (csp_config *) CSP_PCALLOC (p, sizeof(csp_config));

   /*
    * Now fill in the defaults.  If there are any `parent' configuration
    * records, they'll get merged as part of a separate callback.
    */

   cfg->local = 0;
   cfg->congenital = 0;
   cfg->cmode = CONFIG_MODE_DIRECTORY;

   dname = (dname != NULL) ? dname : "";
   cfg->auth_csp_enable[0] = '\0';
   cfg->auth_csp_class[0] = '\0';
   cfg->auth_csp_enabled = 0;
   cfg->csp_enabled = 0;

#if CSP_MODULE_BUILD >= 7
   cfg->csp_maxcon = CSP_MAXCON;
#else
   cfg->csp_maxcon = 0;
#endif

   cfg->csp_file_types[0] = '\0';

   return (void *) cfg;
}



/*
 * This function gets called to merge two per-directory configuration
 * records.  This is typically done to cope with things like .htaccess files
 * or <Location> directives for directories that are beneath one for which a
 * configuration record was already created.  The routine has the
 * responsibility of creating a new record and merging the contents of the
 * other two into it appropriately.  If the module doesn't declare a merge
 * routine, the record for the closest ancestor location (that has one) is
 * used exclusively.
 *
 * The routine MUST NOT modify any of its arguments!
 *
 * The return value is a pointer to the created module-specific structure
 * containing the merged values.
 */

static void *csp_merge_dir_config(pool *p, void *parent_conf, void *newloc_conf)
{
   csp_config *merged_config = (csp_config *) CSP_PCALLOC (p, sizeof(csp_config));
   csp_config *pconf = (csp_config *) parent_conf;
   csp_config *nconf = (csp_config *) newloc_conf;

   /*
    * Some things get copied directly from the more-specific record, rather
    * than getting merged.
    */

   merged_config->local = nconf->local;

   merged_config->csp_enabled = nconf->csp_enabled;
   merged_config->auth_csp_enabled = nconf->auth_csp_enabled;
   merged_config->csp_maxcon = nconf->csp_maxcon;

   strcpy(merged_config->auth_csp_enable, nconf->auth_csp_enable);
   strcpy(merged_config->auth_csp_class, nconf->auth_csp_class);

   strcpy(merged_config->csp_file_types, nconf->csp_file_types);

   /*
    * Others, like the setting of the `congenital' flag, get ORed in.  The
    * setting of that particular flag, for instance, is TRUE if it was ever
    * true anywhere in the upstream configuration.
    */

   merged_config->congenital = (pconf->congenital | pconf->local);

   /*
    * If we're merging records for two different types of environment (server
    * and directory), mark the new record appropriately.  Otherwise, inherit
    * the current value.
    */

   merged_config->cmode = (pconf->cmode == nconf->cmode) ? pconf->cmode : CONFIG_MODE_COMBO;

   return (void *) merged_config;
}



/*
 * This function gets called to create a per-server configuration
 * record.  It will always be called for the "default" server.
 *
 * The return value is a pointer to the created module-specific
 * structure.
 */


static void *csp_create_server_config(pool *p, server_rec *s)
{
   csp_config *cfg;
   char    *sname = s->server_hostname;

   /*
    * As with the csp_create_dir_config() routine, we allocate and fill in an
    * empty record.
    */

   cfg = (csp_config *) CSP_PCALLOC (p, sizeof(csp_config));
   cfg->local = 0;
   cfg->congenital = 0;
   cfg->cmode = CONFIG_MODE_SERVER;

#if CSP_MODULE_BUILD >= 7
   cfg->csp_maxcon = CSP_MAXCON;
#else
   cfg->csp_maxcon = 0;
#endif

   sname = (sname != NULL) ? sname : "";

   return (void *) cfg;
}



/*
 * This function gets called to merge two per-server configuration
 * records.  This is typically done to cope with things like virtual hosts and
 * the default server configuration  The routine has the responsibility of
 * creating a new record and merging the contents of the other two into it
 * appropriately.  If the module doesn't declare a merge routine, the more
 * specific existing record is used exclusively.
 *
 * The routine MUST NOT modify any of its arguments!
 *
 * The return value is a pointer to the created module-specific structure
 * containing the merged values.
 */


static void *csp_merge_server_config(pool *p, void *server1_conf, void *server2_conf)
{
   csp_config *merged_config = (csp_config *) CSP_PCALLOC (p, sizeof(csp_config));
   csp_config *s1conf = (csp_config *) server1_conf;
   csp_config *s2conf = (csp_config *) server2_conf;

   /*
    * Our inheritance rules are our own, and part of our module's semantics.
    * Basically, just note whence we came.
    */

   merged_config->cmode = (s1conf->cmode == s2conf->cmode) ? s1conf->cmode : CONFIG_MODE_COMBO;
   merged_config->local = s2conf->local;
   merged_config->congenital = (s1conf->congenital | s1conf->local);
   merged_config->csp_maxcon = s2conf->csp_maxcon;

   return (void *) merged_config;
}




/*
 * This routine is called to check the authentication information sent with
 * the request (such as looking up the user in a database and verifying that
 * the [encrypted] password sent matches the one in the database).
 *
 * The return value is OK, DECLINED, or some HTTP_mumble error (typically
 * HTTP_UNAUTHORIZED).  If we return OK, no other modules are given a chance
 * at the request during this phase.
 */


static int csp_authenticate_basic_user (request_rec *r)
{
   int result = 0, res = 0, retval;
   const char *user = NULL, *pwd = NULL, *setnull = "null";
   csp_config *conf;

   long n1;
   unsigned int n, total;
   char buffer[1024], header[8192];
   char *lp_general;
   RCB RCB;
   LPRCB pRCB;
   MEMOBJ cgievar, trans_buffer;
   LPMEMOBJ lp_cgievar, lp_trans_buffer;

   pRCB = &RCB;

   pRCB->lp_cspcon = NULL;
   pRCB->lp_data = NULL; /* CMT1226 */

   pRCB->ws_buffer = NULL;
   pRCB->ws_buffer_size = 0;
   pRCB->ws_buffer_size = 0;
   pRCB->ap_timeout = 15000; /* CMT1226 */

   result = HTTP_UNAUTHORIZED;

   conf = (csp_config *) CSP_GET_MODULE_CONFIG(r->per_dir_config, &csp_module);

   if (!conf)
      return DECLINED;

   if (!conf->auth_csp_enabled)
      return DECLINED;

   if (r && r->uri) {
      strncpy(buffer, r->uri, 64);
      buffer[64] = '\0';
      cspLCase(buffer);
      if (strstr(buffer, "nph-cspcgi") || strstr(buffer, "/systems/module.cxw") || strstr(buffer, "/runtime/module.cxw")) {
         /* CMT1226 */
         r->user = (char *) cspuser;
         return OK;
      }
   }

   res = ap_get_basic_auth_pw (r, &pwd);

   if (r->user)
      user = r->user;
   else
      user = setnull;

   /* Authentication done in CSP at page-request time */

   if (conf->auth_csp_class[0] == '\0') {

      if (res == OK)
         return OK;
      else
         return res;
   }

   /* Authentication done in CSP independently of page-request by class defined in AuthCSPClass */

   if (res != OK) {
      return res;
   }

/*
   if (!strcmp(user, "cm") && !strcmp(pwd, "xxx")) {
      return OK;
   }
   else {
      return HTTP_UNAUTHORIZED;
   }
*/

   pRCB = &RCB;
   pRCB->r = r;

   pRCB->csp_form = 1;
   pRCB->soap = 0;
   pRCB->clen = 0;
   pRCB->send_no = 0;
   pRCB->chunked = 0;
   pRCB->request_chunk_no = 0;
   pRCB->request_header_sent = 0;

   pRCB->lp_cspcon = NULL;

   pRCB->lp_trans_buffer = NULL;

   pRCB->ws_buffer = NULL;
   pRCB->ws_buffer_size = 0;
   pRCB->ws_buffer_size = 0;

   lp_cgievar = &cgievar;
   lp_trans_buffer = &trans_buffer;

   request_no ++;

   CSP_ADD_COMMON_VARS(r);
   CSP_ADD_CGI_VARS(r);

   pRCB->lp_method = (char *) r->method;

   cspMemInit(lp_cgievar, 256, 256);
   cspMemInit(lp_trans_buffer, 1024, 256);

   pRCB->lp_cgievar = lp_cgievar;

   cspGetConfiguration(pRCB);

   cspMemCpy(lp_trans_buffer, "#########\r", 10);
   for (n = 0; CgiEnvVars[n]; n ++) {

      if (n == 31)   /* CSP_MODULE_BUILD */
         continue;   /* Pretend we're old protocol then server will close connection  at end of response */

      if (n == 14) {
         n1 = cspGetServerVariable(pRCB, "DOCUMENT_ROOT", lp_cgievar);
         cspMemCat(lp_cgievar, conf->auth_csp_class, strlen(conf->auth_csp_class));
         n1 = lp_cgievar->curr_size;
      }
      else if (n == 20) {
         cspMemCpy(lp_cgievar, "GET", 3);
         n1 = lp_cgievar->curr_size;
      }
      else if (n == 25) {
         cspMemCpy(lp_cgievar, conf->auth_csp_class, strlen(conf->auth_csp_class));
         n1 = lp_cgievar->curr_size;
      }
      else if (n < 32) {
         n1 = cspGetServerVariable(pRCB, CgiEnvVars[n], lp_cgievar);
      }
      else {
         cspMemCpy(lp_cgievar, "", 0);
         n1 = -1;
      }

      if (n1 > -1) {

         if (n == 15 && strstr(lp_cgievar->lp_buffer, "/xml"))
            pRCB->soap = 1;
         if (n == 21)
            pRCB->soap = 1;

         cspMemCat(lp_trans_buffer, CgiEnvVars[n], strlen(CgiEnvVars[n]));
         cspMemCat(lp_trans_buffer, "=", 1);
         cspMemCat(lp_trans_buffer, lp_cgievar->lp_buffer, lp_cgievar->curr_size);
         cspMemCat(lp_trans_buffer, "\r", 1);
      }
   }
   sprintf(buffer, "%d", (lp_trans_buffer->curr_size - 10));
   strncpy(lp_trans_buffer->lp_buffer, buffer, strlen(buffer));
/*
   cspLogEvent(lp_trans_buffer->lp_buffer, "HTTP Authentication: request");
*/
   n = cspOpenConnection(pRCB, 0);

   if (!n) {
      result = SERVER_ERROR;
      goto csp_authenticate_basic_user_exit;
   }

   pRCB->request_header_sent = 1;
   n = cspSendDataToNSD(pRCB, (unsigned char *) lp_trans_buffer->lp_buffer, lp_trans_buffer->curr_size, CSPCON_SEND);

   if (n < 1) {
      result = SERVER_ERROR;
      goto csp_authenticate_basic_user_exit;
   }

   lp_general = NULL;
   total = 8000;
   pRCB->dlen = 0;
   for (;;) {
      pRCB->context = 11;
      sprintf(pRCB->debug_buffer, "ctx=%d; len=%d; get=%d", pRCB->context, pRCB->dlen, (total - pRCB->dlen));

      retval = cspReceiveDataFromNSD(pRCB, (unsigned char *) (header + pRCB->dlen), total - pRCB->dlen);

      if (retval < 1)
         break;
      pRCB->dlen += retval;
      header[pRCB->dlen] = '\0';
      lp_general = strstr(header, "\r\n\r\n");
      if (lp_general || pRCB->dlen == (int) total)
         break;
   }
   header[pRCB->dlen] = '\0';
/*
   cspLogEvent(header, "HTTP Authentication: response");
*/
   pRCB->context = 12;
   sprintf(pRCB->debug_buffer, "ctx=%d; get=%d", pRCB->context, 1000);
   while ((retval = cspReceiveDataFromNSD(pRCB, (unsigned char *) buffer, 1000)) > 0)
      ;

   if (lp_general && !strncmp(header, "HTTP/", 5)) {
      lp_general = strstr(header, "\r\n");
      if (lp_general) {
         *lp_general = '\0';
         if (strstr(header, "200"))
            result = OK;
         else if (strstr(header, "401")) {
            ap_note_basic_auth_failure(r);
            result = HTTP_UNAUTHORIZED;
         }
         else
            result = SERVER_ERROR;
      }
      else
         result = SERVER_ERROR;
   }
   else
      result = SERVER_ERROR;

csp_authenticate_basic_user_exit:

   cspMemFree(lp_cgievar);
   cspMemFree(lp_trans_buffer);

   return result;
}



/*
 * This routine is called to check to see if the resource being requested
 * requires authorization.
 *
 * The return value is OK, DECLINED, or HTTP_mumble.  If we return OK, no
 * other modules are called during this phase.
 *
 * If *all* modules return DECLINED, the request is aborted with a server
 * error.
 */


static int csp_check_auth(request_rec *r)
{
   csp_config *conf;

   conf = (csp_config *) CSP_GET_MODULE_CONFIG(r->per_dir_config, &csp_module);

   if (conf->auth_csp_enabled)
      return OK;
   else
      return DECLINED;

}




/*--------------------------------------------------------------------------*/
/*                                                                          */
/* Which functions are responsible for which hooks in the server.           */
/*                                                                          */
/*--------------------------------------------------------------------------*/
/* 
 * Each function our module provides to handle a particular hook is
 * specified here.  The functions are registered using 
 * ap_hook_foo(name, predecessors, successors, position)
 * where foo is the name of the hook.
 *
 * The args are as follows:
 * name         -> the name of the function to call.
 * predecessors -> a list of modules whose calls to this hook must be
 *                 invoked before this module.
 * successors   -> a list of modules whose calls to this hook must be
 *                 invoked after this module.
 * position     -> The relative position of this module.  One of
 *                 APR_HOOK_FIRST, APR_HOOK_MIDDLE, or APR_HOOK_LAST.
 *                 Most modules will use APR_HOOK_MIDDLE.  If multiple
 *                 modules use the same relative position, Apache will
 *                 determine which to call first.
 *                 If your module relies on another module to run first,
 *                 or another module running after yours, use the 
 *                 predecessors and/or successors.
 *
 * The number in brackets indicates the order in which the routine is called
 * during request processing.  Note that not all routines are necessarily
 * called (such as if a resource doesn't have access restrictions).
 * The actual delivery of content to the browser [9] is not handled by
 * a hook; see the handler declarations below.
 */

static void csp_register_hooks(apr_pool_t *p)
{

   ap_hook_post_config(csp_init, NULL, NULL, APR_HOOK_MIDDLE);
   ap_hook_child_init(csp_child_init, NULL, NULL, APR_HOOK_MIDDLE);
	ap_hook_check_user_id(csp_authenticate_basic_user, NULL, NULL, APR_HOOK_MIDDLE);
	ap_hook_auth_checker(csp_check_auth, NULL, NULL, APR_HOOK_MIDDLE);
/* CMT1226 */
    ap_hook_check_authn(csp_authenticate_basic_user, NULL, NULL, APR_HOOK_MIDDLE, AP_AUTH_INTERNAL_PER_CONF);
    /* ap_hook_check_authz(x_check_authz, NULL, NULL, APR_HOOK_MIDDLE, AP_AUTH_INTERNAL_PER_CONF); */
   ap_hook_handler(csp_handler, NULL, NULL, APR_HOOK_MIDDLE);


   return;
}



/*--------------------------------------------------------------------------*/
/*                                                                          */
/* All of the routines have been declared now.  Here's the list of          */
/* directives specific to our module, and information about where they      */
/* may appear and how the command parser should pass them to us for         */
/* processing.  Note that care must be taken to ensure that there are NO    */
/* collisions of directive names between modules.                           */
/*                                                                          */
/*--------------------------------------------------------------------------*/
/* 
 * List of directives specific to our module.
 */

static const command_rec csp_commands [] = {

   AP_INIT_RAW_ARGS("AuthCSPEnable", csp_cmd, NULL, OR_FILEINFO,
      "set to 'On' to enable CSP-based HTTP authentication"),

   AP_INIT_RAW_ARGS("AuthCSPClass", csp_cmd, NULL, OR_FILEINFO,
      "optional class to handle HTTP authentication"),

   AP_INIT_RAW_ARGS("CSPFileTypes", csp_cmd, NULL, OR_FILEINFO,
      "optional list of file types (by extension) to be processed by CSP"),

   AP_INIT_RAW_ARGS("CSP", csp_cmd, NULL, OR_FILEINFO,
      "set to 'On' to enable the entire location to be processed with CSP"),

   AP_INIT_RAW_ARGS("CSPMaxPooledNSDConnections", csp_cmd, NULL, OR_FILEINFO,
      "set to the maximum number of pooled connections to the NSD per child process; set to 0 to disable connection pooling"),

   { NULL }
};



/*--------------------------------------------------------------------------*/
/*                                                                          */
/* Finally, the list of callback routines and data structures that          */
/* provide the hooks into our module from the other parts of the server.    */
/*                                                                          */
/*--------------------------------------------------------------------------*/
/* 
 * Module definition for configuration.  If a particular callback is not
 * needed, replace its routine name below with the word NULL.
 *
 * The number in brackets indicates the order in which the routine is called
 * during request processing.  Note that not all routines are necessarily
 * called (such as if a resource doesn't have access restrictions).
 */


module AP_MODULE_DECLARE_DATA csp_module = {

   STANDARD20_MODULE_STUFF,
   csp_create_dir_config,        /* per-directory config creater */
   csp_merge_dir_config,         /* dir config merger - default is to override */
   csp_create_server_config,     /* server config creator */
   csp_merge_server_config,      /* server config merger */
   csp_commands,                 /* command table */
   csp_register_hooks,           /* set up other request processing hooks */
};


/* Functions responsible for communicating with the NSD module follow */

int cspCheckFileType(RCB *pRCB, char *type)
{
   int result;
   char buffer[32];

   /* CMT781 */
   strcpy(buffer, ".");
   strncpy(buffer + 1, type, 10);
   buffer[11] = '\0';
   strcat(buffer, ".");

   if (strstr(CSP_FILE_TYPES, buffer))
      result = 1;
   else if (pRCB->dconf && pRCB->dconf->csp_file_types[0] && (strstr(pRCB->dconf->csp_file_types, buffer) || strstr(pRCB->dconf->csp_file_types, ".*.")))
      result = 2;
   else if (pRCB->sconf && pRCB->sconf->csp_file_types[0] && (strstr(pRCB->sconf->csp_file_types, buffer) || strstr(pRCB->dconf->csp_file_types, ".*.")))
      result = 3;
   else
      result = 0;
/*
   ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp: cspCheckFileType: result=%d; pRCB->dconf->csp_file_types=%s; pRCB->dconf->csp_file_types=%s; buffer=%s", result, pRCB->dconf->csp_file_types, pRCB->sconf->csp_file_types, buffer);
*/
   return result;
}


int cspGetConfiguration(RCB *pRCB)
{
   short env_config;
   int len, len1;
   char buffer[128], tcp_port[128], nsd_ini[128];
   FILE *fp;

   strcpy(pRCB->ip_address, SA_IP_ADDRESS);
   pRCB->port = (int) strtol(SA_TCP_PORT, NULL, 10);

   env_config = 0;
   len = 0;
   *tcp_port = '\0';
   *buffer = '\0';

   len = cspGetServerVariable(pRCB, "CSP_DEBUG", pRCB->lp_cgievar);
   if (len > 0)
      pRCB->debug = 1;

   len = cspGetServerVariable(pRCB, "CSP_ERROR_PAGE_NSD_DOWN", pRCB->lp_cgievar);
   if (len > 0)
      strcpy(pRCB->error_redir, pRCB->lp_cgievar->lp_buffer);
   else
      strcpy(pRCB->error_redir, "");

   len = cspGetServerVariable(pRCB, "CSP_NSD_NAME", pRCB->lp_cgievar);
   if (len > 0)
      strcpy(pRCB->ip_address, pRCB->lp_cgievar->lp_buffer);

   len = cspGetServerVariable(pRCB, "CSP_NSD_PORT", pRCB->lp_cgievar);
   if (len > 0) {
      len1 = (int) strtol(pRCB->lp_cgievar->lp_buffer, NULL, 10);
      if (len1) {
         pRCB->port = len1;
         env_config = 1;
      }
   }

   if (!env_config) {

#if defined(_WIN32)

      strcpy(nsd_ini, SA_INI_FILE);
      fp = fopen(nsd_ini, "r");

      len = GetPrivateProfileString("SYSTEM", "Ip_Address", "", buffer, 31, nsd_ini);
      if (len)
         strcpy(pRCB->ip_address, buffer);
      GetPrivateProfileString("SYSTEM", "TCP_Port", "", tcp_port, 31, nsd_ini);

      if (strlen(tcp_port))
         pRCB->port = (int) strtol(tcp_port, NULL, 10);

#else

      sprintf(nsd_ini, "%s/%s", SA_PATH_1, SA_INI_FILE);
      fp = fopen(nsd_ini, "r");
      if (!fp) {
         sprintf(nsd_ini, "%s/%s", SA_PATH_2, SA_INI_FILE);
         fp = fopen(nsd_ini, "r");
         if (!fp) {
            sprintf(nsd_ini, "%s/%s", SA_PATH_3, SA_INI_FILE);
            fp = fopen(nsd_ini, "r");
         }
      }

      if (fp) {
         while (fgets(buffer, 64, fp)) {
            len = strlen(buffer) - 1;
            buffer[len] = '\0';
            if (len > 11 && !strncmp(buffer, "Ip_Address=", 11))
               strcpy(pRCB->ip_address, buffer + 11);
            else if (len > 11 && strncmp(buffer, "TCP_Port=", 9))
               strcpy(tcp_port, buffer + 9);
         }

         fclose(fp);

         if (strlen(tcp_port))
            pRCB->port = (int) strtol(tcp_port, NULL, 10);
      }

#endif
   }

   return 1;
}


int cspOpenConnection(RCB *pRCB, short context)
{
   int result;
   int n, chndle, first_slot, retval;

   retval = 0;

   strcpy(pRCB->error, "");

   pRCB->eod = 0;
   pRCB->lp_cspcon = NULL;
   pRCB->chndle = -1;
   chndle = -1;
   first_slot = -1;
   result = 0;

   if (csp_maxcon > 0) {
#if CSP_USE_THREADS
      if (cspcon_lock)
         retval = apr_thread_mutex_lock(cspcon_lock);
#endif

      for (n = 0; n < csp_maxcon; n ++) {
         if (CSPCONTable[n]) {
            if (CSPCONTable[n]->status == CSPCON_STATUS_FREE && CSPCONTable[n]->con_status == CSPCON_CON_STATUS_CON && CSPCONTable[n]->port == pRCB->port && !strcmp(CSPCONTable[n]->ip_address, pRCB->ip_address)) {
               CSPCONTable[n]->status = CSPCON_STATUS_INUSE;
               chndle = n;
               break;
            }
            else if (first_slot == -1 && CSPCONTable[n]->status == CSPCON_STATUS_FREE && CSPCONTable[n]->con_status == CSPCON_CON_STATUS_DSCON)
               first_slot = n;
         }
         else if (first_slot == -1)
            first_slot = n;
      }

      if (chndle != -1) { /* Reuse open connection */
         pRCB->chndle = chndle;
         pRCB->lp_cspcon = CSPCONTable[chndle];
/*
         ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp: cspOpenConnection reuse connection: pRCB->lp_cspcon=%x; pRCB->chndle=%d", pRCB->lp_cspcon, pRCB->chndle);
*/
         result = 2;
      }
      else if (first_slot != -1) { /* Create new connection in pool */
         result = 1;
         if (!CSPCONTable[first_slot]) {
            CSPCONTable[first_slot] = (CSPCON *) malloc(sizeof(CSPCON));
            if (!CSPCONTable[first_slot]) {
               result = 0;
            }
         }
         if (result) {
            CSPCONTable[first_slot]->status = CSPCON_STATUS_INUSE;
            pRCB->chndle = first_slot;
            pRCB->lp_cspcon = CSPCONTable[first_slot];
         }
      }

#if CSP_USE_THREADS
      if (cspcon_lock)
         retval = apr_thread_mutex_unlock(cspcon_lock);
#endif
   }

   if (result == 2) {
/*
{
   char buffer[256];
   sprintf(buffer, "cspOpenConnectionEx result=%d (REUSE); chndle=%d", result, pRCB->chndle);
   cspLogEvent(buffer, "cspOpenConnectionEx");
}
*/
      return result; /* Reuse open connection */
   }

   if (!pRCB->lp_cspcon) { /* Create new connection just for this request */
      pRCB->lp_cspcon = (CSPCON *) malloc(sizeof(CSPCON));
   }

   if (!pRCB->lp_cspcon) { /* Unable to allocate memory */
      result = 0;
      return result;
   }

   pRCB->lp_cspcon->status = CSPCON_STATUS_INUSE;

   result = cspOpenConnectionEx(pRCB, 0);

/*
{
   char buffer[256];
   sprintf(buffer, "cspOpenConnectionEx result=%d; chndle=%d", result, pRCB->chndle);
   cspLogEvent(buffer, "cspOpenConnectionEx");
}
*/

   return result;

}


int cspOpenConnectionEx(RCB *pRCB, short context)
{
   short ipv6, getaddrinfo_ok, connected;
   const int on = 1;
   int n, result;
   static struct sockaddr_in cli_addr, srv_addr;

   strcpy(pRCB->lp_cspcon->ip_address, pRCB->ip_address);
   pRCB->lp_cspcon->port = pRCB->port;
   pRCB->lp_cspcon->cspnsd_build = 0;

/*
   ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp: cspOpenConnectionEx: pRCB->lp_cspcon=%x; pRCB->chndle=%d", pRCB->lp_cspcon, pRCB->chndle);
*/

   getaddrinfo_ok = 0;
   connected = 0;
   result = 0;

   cspLoadNet(0);
#ifdef _WIN32
   if (csp_sock.wsastartup != 0) {
      sprintf(pRCB->error, "Microsoft WSAStartup Failed (%d)", CSP_GET_LAST_ERROR);
      result = 0;
      goto cspOpenConnectionExExit;
   }
#endif

   ipv6 = csp_sock.ipv6;

#if defined(CSP_IPV6)
   if (ipv6) {
      short mode;
      struct addrinfo hints, *res;
      struct addrinfo *ai;
      char port_str[32];
	   int off = 0;
	   int ipv6_v6only = 27;

      res = NULL;
      sprintf(port_str, "%d", pRCB->lp_cspcon->port);
      connected = 0;

      for (mode = 0; mode < 3; mode ++) {

         if (res) {
            CSPNET_FREEADDRINFO(res);
            res = NULL;
         }

         memset(&hints, 0, sizeof hints);
         hints.ai_family = AF_UNSPEC;     /* Use IPv4 or IPv6 */
         hints.ai_socktype = SOCK_STREAM;
         /* hints.ai_flags = AI_PASSIVE; */
         if (mode == 0)
            hints.ai_flags = AI_NUMERICHOST | AI_CANONNAME;
         else if (mode == 1)
            hints.ai_flags = AI_CANONNAME;
         else if (mode == 2) {
            /* Apparently an error can occur with AF_UNSPEC (See RJW1564) */
            /* This iteration will return IPV6 addresses if any */
            hints.ai_flags = AI_CANONNAME;
            hints.ai_family = AF_INET6;
         }
         else
            break;

         n = CSPNET_GETADDRINFO(pRCB->lp_cspcon->ip_address, port_str, &hints, &res);
         if (n != 0) {
            continue;
         }

         getaddrinfo_ok = 1;
         for (ai = res; ai != NULL; ai = ai->ai_next) {
/*
            ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp: IPv6: getaddrinfo(): ai->ai_family=%d; AF_INET=%d; AF_INET6=%d; ai->ai_family=%d; ai->ai_protocol=%d", ai->ai_family, AF_INET, AF_INET6, ai->ai_family, ai->ai_protocol);
*/
	         if (ai->ai_family != AF_INET && ai->ai_family != AF_INET6) {
               continue;
            }

	         /* Open a socket with the correct address family for this address. */
	         pRCB->lp_cspcon->sockfd = CSPNET_SOCKET(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
            /* bind(DBCTable[chndle]->cli_socket, ai->ai_addr, (int) (ai->ai_addrlen)); */

            n = CSPNET_CONNECT(pRCB->lp_cspcon->sockfd, ai->ai_addr, (int) (ai->ai_addrlen));

            if (n < 0) {
               sprintf(pRCB->error, "Cannot Connect to the CSP NSD (%s:%d): Error Code: %d", pRCB->lp_cspcon->ip_address, pRCB->lp_cspcon->port, CSP_GET_LAST_ERROR);
#ifdef _WIN32
               CSPNET_CLOSESOCKET(pRCB->lp_cspcon->sockfd);
#else
               close(pRCB->lp_cspcon->sockfd);
#endif
               continue;
            }
            else {
               connected = 1;
               break;
            }
         }
         if (connected)
            break;
      }
      if (res) {
         CSPNET_FREEADDRINFO(res);
         res = NULL;
      }
   }
#endif

   if (ipv6) {
      if (connected) {
/*
         ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp: IPv6: getaddrinfo(): connected");
*/
         result = 1;
         goto cspOpenConnectionExExit;
      }
      else {
         if (getaddrinfo_ok) {
            sprintf(pRCB->error, "Cannot identify CSP NSD: Error Code: %d", CSP_GET_LAST_ERROR);
            cspCloseConnectionEx(pRCB, CSPCON_CLOSE_SOFT_DSCON);
            result = 0;
            goto cspOpenConnectionExExit;
         }
         else {
            sprintf(pRCB->error, "mod_csp: Cannot connect over IPv6 - will attempt to use the IPv4 stack instead (%s:%d): Error Code: %d", pRCB->lp_cspcon->ip_address, pRCB->lp_cspcon->port, CSP_GET_LAST_ERROR);
            ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "%s", pRCB->error);
            strcpy(pRCB->error, "");
         }
      }
   }

   ipv6 = 0;

#if defined(CSP_UNIX)
   bzero((char *) &srv_addr, sizeof(srv_addr));
#endif

   srv_addr.sin_port = CSPNET_HTONS((unsigned short) pRCB->port);
   srv_addr.sin_family = AF_INET;
   srv_addr.sin_addr.s_addr = CSPNET_INET_ADDR(pRCB->ip_address);

   pRCB->lp_cspcon->sockfd = CSPNET_SOCKET(AF_INET, SOCK_STREAM, 0);
   if (pRCB->lp_cspcon->sockfd < 0) {
      sprintf(pRCB->error, "Can't open a stream-socket to CSP (%d)", CSP_GET_LAST_ERROR);

      result = 0;
      goto cspOpenConnectionExExit;
   }

#if defined(CSP_UNIX)
   bzero((char *) &cli_addr, sizeof(cli_addr));
#endif

   cli_addr.sin_family = AF_INET;
   cli_addr.sin_addr.s_addr = CSPNET_HTONL(INADDR_ANY);
   cli_addr.sin_port = CSPNET_HTONS(0);

   n = CSPNET_BIND(pRCB->lp_cspcon->sockfd, (struct sockaddr *) &cli_addr, sizeof(cli_addr));
   if (n < 0) {
      sprintf(pRCB->error, "Can't bind to local address for CSP access (%d)", CSP_GET_LAST_ERROR);
      cspCloseConnectionEx(pRCB, CSPCON_CLOSE_SOFT_DSCON);
      result = 0;
      goto cspOpenConnectionExExit;
   }

   n = CSPNET_CONNECT(pRCB->lp_cspcon->sockfd, (struct sockaddr *) &srv_addr, sizeof(srv_addr));

   if (n < 0) {
      sprintf(pRCB->error, "Can't connect to the CSP NSD (%d)",  CSP_GET_LAST_ERROR);
      cspCloseConnectionEx(pRCB, CSPCON_CLOSE_SOFT_DSCON);
      result = 0;
      goto cspOpenConnectionExExit;
   }

   result = 1;

cspOpenConnectionExExit:

   if (result)
      pRCB->lp_cspcon->con_status = CSPCON_CON_STATUS_CON;

   return result;
}


int cspCloseConnection(RCB *pRCB, short context)
{

   if (!pRCB->lp_cspcon)
      return -1;

/*
   ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp: cspCloseConnection: pRCB->lp_cspcon=%x; pRCB->chndle=%d; pRCB->lp_cspcon->status=%d; context=%d", pRCB->lp_cspcon, pRCB->chndle, pRCB->lp_cspcon->status, context);
*/

   if (pRCB->chndle == -1 || context == CSPCON_CLOSE_SOFT_DSCON || context == CSPCON_CLOSE_HARD) {
      cspCloseConnectionEx(pRCB, context);
   }

   if (pRCB->chndle == -1) { /* non-cached connection */
      free((void *) pRCB->lp_cspcon);
      pRCB->lp_cspcon = NULL;
   }
   else {
      pRCB->chndle = -1;
      pRCB->lp_cspcon->status = CSPCON_STATUS_FREE;
      pRCB->lp_cspcon = NULL;
   }

   return 1;
}


int cspCloseConnectionEx(RCB *pRCB, short context)
{
#ifndef _WIN32
   int n;
   struct linger ling;
   ling.l_onoff = 1;
   ling.l_linger = 0;
#endif

   if (!pRCB->lp_cspcon)
      return -1;

   if (pRCB->lp_cspcon->con_status == CSPCON_CON_STATUS_DSCON)
      return 0;
/*
   ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp (%d.%d): hard close (pRCB->chndle=%d, context=%d)", CSP_MODULE_BUILD, CSP_ADHOC_BUILD, pRCB->chndle, context);
*/

#ifdef _WIN32
   CSPNET_CLOSESOCKET(pRCB->lp_cspcon->sockfd);
#else /* UNIX */
   n = CSPNET_SETSOCKOPT(pRCB->lp_cspcon->sockfd, SOL_SOCKET, SO_LINGER, (void *) &ling, sizeof(ling));
   close(pRCB->lp_cspcon->sockfd);
#endif

   pRCB->lp_cspcon->con_status = CSPCON_CON_STATUS_DSCON;

   return 1;
}


int cspTestConnection(RCB *pRCB, short context)
{
   int result;

   result = 0;

   if (pRCB->lp_cspcon->cspnsd_build < 9999)
      result = 0;

   return result;   
}


int cspSendDataToNSD(RCB *pRCB, unsigned char *data, int data_size, short context)
{
   int n, sent;
   unsigned int head_len, tail_len;
   char *p_head;
   char head[16], tail[16];

   if (!pRCB->lp_cspcon)
      return -1;

   sent = 0;
   head_len = 0;
   tail_len = 0;
   p_head = NULL;

   if (!pRCB->request_header_sent) {
      p_head = pRCB->lp_trans_buffer->lp_buffer;
      head_len += pRCB->lp_trans_buffer->curr_size;
   }

   if (pRCB->request_chunked) {
      if (data_size) {
         sprintf(head, "%s%x\r\n", pRCB->request_chunk_no ? "\r\n" : "", data_size);
         pRCB->request_chunk_no ++;
         head_len += strlen(head);
         if (pRCB->request_header_sent) {
            p_head = head;
         }
         else {
            cspMemCat(pRCB->lp_trans_buffer, head, head_len);
         }
      }
      if (context == CSPCON_SEND_WITH_EOF) {
         sprintf(tail, "%s0\r\n\r\n", pRCB->request_chunk_no ? "\r\n" : "");
         pRCB->request_chunk_no ++;
         tail_len = strlen(tail);
         if (!pRCB->request_header_sent && !data_size) {
            cspMemCat(pRCB->lp_trans_buffer, tail, tail_len);
            head_len += strlen(tail);
            tail_len = 0;
         }
      }
   }

   if (head_len && !data && head_len <= pRCB->lp_cspcon->buffer_ptr) {
      pRCB->lp_cspcon->buffer_ptr -= head_len;
      strncpy((char *) (pRCB->lp_cspcon->buffer + pRCB->lp_cspcon->buffer_ptr), p_head, head_len);
      data_size += head_len;
      pRCB->lp_cspcon->buffer_curr_size += head_len;
      head_len = 0;
   }

   if (tail_len && !data) {
      strncpy((char *) (pRCB->lp_cspcon->buffer + (pRCB->lp_cspcon->buffer_ptr + data_size)), tail, tail_len);
      data_size += tail_len;
      pRCB->lp_cspcon->buffer_curr_size += tail_len;
      tail_len = 0;
   }

   if (pRCB->send_no == 0 && pRCB->open_status == 2 && (head_len || tail_len || context != CSPCON_SEND_WITH_EOF)) {
      /* Request does not fit into one buffer and connection is a 'reused' connection.  Therefore test connection */
/*
      cspLogEvent("test connection", "cspSendDataToNSD");
*/
      if (!cspTestConnection(pRCB, 0)) {

         n = cspCloseConnectionEx(pRCB, CSPCON_CLOSE_SOFT_DSCON);
         pRCB->open_status = cspOpenConnectionEx(pRCB, 0);

         if (!pRCB->open_status) {
/*
{
   char buffer[256];
   sprintf(buffer, "CANNOT RECOVER CONNECTION chndle=%d", pRCB->chndle);
   cspLogEvent(buffer, "cspSendDataToNSDEx");
}
*/

            sent = -9;
            goto cspSendDataToNSDExit;
         }
      }
   }

   if (head_len) {
      n = cspSendDataToNSDEx(pRCB, (unsigned char *) p_head, head_len, context);
      if (n < 0) {
         sent = n;
         goto cspSendDataToNSDExit;
      }
      sent += n;
   }


   if (data_size) {
      if (data)
         n = cspSendDataToNSDEx(pRCB, (unsigned char *) data, data_size, context);
      else
         n = cspSendDataToNSDEx(pRCB, (unsigned char *) pRCB->lp_cspcon->buffer + pRCB->lp_cspcon->buffer_ptr, data_size, context);

      if (n < 0) {
         sent = n;
         goto cspSendDataToNSDExit;
      }
      sent += n;
   }

   if (tail_len) {
      n = cspSendDataToNSDEx(pRCB, (unsigned char *) tail, tail_len, context);
      if (n < 0) {
         sent = n;
         goto cspSendDataToNSDExit;
      }
      sent += n;
   }


cspSendDataToNSDExit:

   pRCB->request_header_sent = 1;

   return sent;
}



int cspSendDataToNSDEx(RCB *pRCB, unsigned char *data, int data_size, short context)
{
   int n, sent, attempt_no, nodata;

/*
   data[data_size] = '\0';
   ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp: cspSendDataToNSDEx: pRCB->send_no=%d; size=%d; content=%s ", pRCB->send_no, data_size, "data");
*/

   pRCB->send_no ++;
   sent = 0; /* CMT1179 */
   nodata = 0;

   for (attempt_no = 0; ; attempt_no ++) {
      sent = 0;
      nodata = 0;

      for (;;) {
         n = CSPNET_SEND(pRCB->lp_cspcon->sockfd, data + sent, data_size - sent, 0);
         if (n == 0) { /* CMT1179: This shouldn't happen but we'll test just to be safe */
            nodata ++;
            if (nodata > 100) {
               n = -2;
               break;
            }
            continue;
         }
         nodata = 0;
         if (n < 0) {
            sent = n;
            break;
         }
         sent += n;
         if (sent == data_size) {
            break;
         }
      }

      if (sent == data_size) {
         break;
      }

      if (pRCB->send_no == 1 && pRCB->open_status == 2) { /* Previous connection a 'reuse' so it's OK to try again */
         sent = 0; /* CMT1179 */
/*
         ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp: cspSendDataToNSDEx FAILED: pRCB->open_status=%d; pRCB->chndle=%d; sent=%d", pRCB->open_status, pRCB->chndle, sent);
*/


         n = cspCloseConnectionEx(pRCB, CSPCON_CLOSE_SOFT_DSCON);
         pRCB->open_status = cspOpenConnectionEx(pRCB, 0);

         if (!pRCB->open_status) { /* Cannot re-establish a connection */
/*
{
   char buffer[256];
   sprintf(buffer, "CANNOT RECOVER chndle=%d", pRCB->chndle);
   cspLogEvent(buffer, "cspSendDataToNSDEx");
}
*/
            sent = -9;
            break;
         }
/*
{
   char buffer[256];
   sprintf(buffer, "RECOVERED chndle=%d", pRCB->chndle);
   cspLogEvent(buffer, "cspSendDataToNSDEx");
}
*/

      }

      if (sent < 0) { /* CMT1179: Cannot communicate with (or re-establish connectivity to) the NSD */
         ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp: cspSendDataToNSDEx() FAILED to communicate with NSD (open_status=%d; chndle=%d; sent=%d)", pRCB->open_status, pRCB->chndle, sent);
         break;
      }

   }

   return sent;
}


int cspReceiveDataFromNSD(RCB *pRCB, unsigned char *data, int data_size)
{
   int n, timeout;
   fd_set rset, eset;
   struct timeval tval;

   if (!pRCB->lp_cspcon)
      return -1;

   if (pRCB->eod)
      return 0;

   FD_ZERO(&rset);
   FD_ZERO(&eset);
   FD_SET(pRCB->lp_cspcon->sockfd, &rset);
   FD_SET(pRCB->lp_cspcon->sockfd, &eset);

   timeout = (pRCB->ap_timeout - 5000);
   tval.tv_sec = timeout / 1000;
   tval.tv_usec = timeout % 1000;

/*
      ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp (%d.%d): read timeout:  tval.tv_sec=%d;  tval.tv_usec=%d;", CSP_MODULE_BUILD, CSP_ADHOC_BUILD, tval.tv_sec, tval.tv_usec);
*/

   n = CSPNET_SELECT(pRCB->lp_cspcon->sockfd + 1, &rset, NULL, &eset, &tval);

   if (n == 0) {

      /* CMT805 */
      ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp (%d.%d): request timed-out (context=%d; chndle=%d; apache_timeout(-5)=%u; header_size=%d; ws_headers=%d; chunked=%d; clen_supplied=%d; clen=%ld; rlen=%ld; dlen=%d; get=%d; uri=%s; response_header=%s)", CSP_MODULE_BUILD, CSP_ADHOC_BUILD, pRCB->context, pRCB->chndle, timeout / 1000, pRCB->hlen, pRCB->ws_headers, pRCB->chunked, pRCB->clen_supplied, pRCB->clen, pRCB->rlen, pRCB->dlen, data_size, pRCB->r->uri, pRCB->debug_header);
/*
      ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp (%d.%d): request timed-out (context=%d; chndle=%d; apache_timeout(-5)=%u; header_size=%d; ws_headers=%d; chunked=%d; clen_supplied=%d; clen=%ld; rlen=%ld; dlen=%d; get=%d; uri=%s; debug_buffer=%s)", CSP_MODULE_BUILD, CSP_ADHOC_BUILD, pRCB->context, pRCB->chndle, timeout / 1000, pRCB->hlen, pRCB->ws_headers, pRCB->chunked, pRCB->clen_supplied, pRCB->clen, pRCB->rlen, pRCB->dlen, data_size, pRCB->r->uri, pRCB->debug_buffer);
      ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp (%d.%d): request timed-out (context=%d; respose_buffer=%s)", CSP_MODULE_BUILD, CSP_ADHOC_BUILD, pRCB->context, pRCB->lp_cspcon->buffer);
*/
      pRCB->eod = 1;
      return -2;
   }

   if (n < 0 || !FD_ISSET(pRCB->lp_cspcon->sockfd, &rset)) {

      if (pRCB->context != 12) { /* CMT1226 */
         ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp (%d.%d): network error (context=%d; chndle=%d; header_size=%d; ws_headers=%d; chunked=%d; clen_supplied=%d; clen=%ld; rlen=%ld; dlen=%d; get=%d; uri=%s; header=%s)", CSP_MODULE_BUILD, CSP_ADHOC_BUILD, pRCB->context, pRCB->chndle, pRCB->hlen, pRCB->ws_headers, pRCB->chunked, pRCB->clen_supplied, pRCB->clen, pRCB->rlen, pRCB->dlen, data_size, pRCB->r->uri, pRCB->debug_header);
      }

      pRCB->eod = 1;
      return -1;
   }

   n = CSPNET_RECV(pRCB->lp_cspcon->sockfd, data, data_size, 0);

   if (n < 1) {

      if (pRCB->context != 12) { /* CMT1226 */
         ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp (%d.%d): network error (context=%d; chndle=%d; header_size=%d; ws_headers=%d; chunked=%d; clen_supplied=%d; clen=%ld; rlen=%ld; dlen=%d; get=%d; uri=%s; header=%s)", CSP_MODULE_BUILD, CSP_ADHOC_BUILD, pRCB->context, pRCB->chndle, pRCB->hlen, pRCB->ws_headers, pRCB->chunked, pRCB->clen_supplied, pRCB->clen, pRCB->rlen, pRCB->dlen, data_size, pRCB->r->uri, pRCB->debug_header);
      }

      pRCB->eod = 1;
   }
   else {
      if (pRCB->lp_data && (pRCB->lp_data->curr_size + n) < (CACHE_BUFFER * 2)) { /* CMT1226 */
         cspMemCat(pRCB->lp_data, (char *) data, n);
      }
   }

   return n;
}


/** Send the HTTP headers for the response.
 * 
 * `ws_headers` is a non-NULL pointer to a boolean that suggests whether to allow the
 * web server to parse the submitted headers. This function may ignore the suggestion, in
 * which case `ws_headers` is set to a boolean indicating whether we are actually allowing
 * the web server to parse the submitted headers. */
int cspSendResponseHeader(RCB *pRCB, char *header, short keepalive, short *ws_headers, short context)
{

   conn_rec *c;
   struct ap_filter_t *cur;

   if (keepalive || pRCB->r->proto_num >= HTTP_VERSION(2, 0))
      *ws_headers = 1;

   if (*ws_headers) {

      int n, status, set_cookie;
      double version;
      char *p, *p1, *p2, *p3;
      char pvers[32], stat[32], desc[32];

      version = 1.1;
      status = 200;
      strcpy(desc, "OK");

      set_cookie = 0;

      for (p = header, n = 0;; n ++) {
         p1 = strstr(p, "\r\n");
         if (!p1)
            break;
         *p1 = '\0';
         if (!strlen(p))
            break;

         if (!n) {
            p2 = strstr(p, "/");
            p3 = strstr(p, " ");
            if (p3) {
               *p3 = '\0';
               strcpy(pvers, p2 + 1);
               version = (double) strtod(pvers, NULL);
               if (!version)
                  version = 1.1;
               *p3 = ' ';
               while (*p3 == ' ')
                  p3 ++;
               p2 = strstr(p3, " ");
               if (p2)
                  *p2 = '\0';
               strcpy(stat, p3);
               if (p2) {
                  *p2 = ' ';
                  while (*p2 == ' ')
                     p2 ++;
                  strcpy(desc, p2);
                  if (!strlen(desc))
                     strcpy(desc, "OK");
               }
               status = (int) strtol(stat, NULL, 10);
               if (!status)
                  status = 200;

               pRCB->r->status = status;
            }
         }
         else {
            p2 = strstr(p, ":");
            if (p2) {
               *p2 = '\0';
               p3 = p2 + 1;
               while (*p3 == ' ')
                  p3 ++;

               cspLCase(p);
               if (!strcmp(p, "content-type")) { /* CMT1552 */
                  int ctsize;
                  char *ct;

                  ctsize = (int) strlen(p3) + 1;
                  ct = (char *) CSP_PCALLOC(pRCB->r->pool, ctsize);
                  strcpy(ct, p3);
                  pRCB->r->content_type = ct;
/*
                  ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "HTTP Response Headers: content-type=%s;", ct);
*/
/*
                  pRCB->r->content_type = p3;
*/
               }
               else {
                  if (!strcmp(p, "set-cookie")) {
                     if (!set_cookie) { /* CMT672 */
                        CSP_TABLE_SET(pRCB->r->headers_out, p, p3);
                     }
                     else {
                        CSP_TABLE_ADD(pRCB->r->headers_out, p, p3);
                     }
                     set_cookie ++;
                  } else if (pRCB->r->proto_num < HTTP_VERSION(2, 0) ||
                             strcmp(p, "transfer-encoding") && strcmp(p, "keep-alive") && strcmp(p, "connection"))
                  {
                     // For HTTP/2 requests, ignore Transfer-Encoding,
                     // Keep-Alive, and Connection headers.
                     CSP_TABLE_SET(pRCB->r->headers_out, p, p3);
                  }
               }

               *p2 = ':';
            }
         }

         p = p1 + 2;
      }


   }
   else {
      int status;
      char *p;

      c = pRCB->r->connection;
      cur = pRCB->r->proto_output_filters;
      while (cur && cur->frec->ftype < AP_FTYPE_CONNECTION) {
         cur = cur->next;
      }
      pRCB->r->output_filters = pRCB->r->proto_output_filters = cur;

      p = strstr(header, " ");
      if (p) {
         p += 1;
         status = strtol(p, NULL, 10);
         if (status) {
/*
   ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp: cspSendResponseHeader: status=%d;", status);
*/
            pRCB->r->status = status;
         }
      }

      if (!pRCB->lp_cspcon) {

         cspWriteString(pRCB, header, 0);
/*
         cspWriteBuffer(pRCB, (void *) header, strlen(header), 0);
*/
      }
      else {
         if (header != (char *) pRCB->lp_cspcon->buffer) {

            cspWriteString(pRCB, header, 0);
/*
            cspWriteBuffer(pRCB, (void *) header, strlen(header), 0);
*/
         }
      }

   }

   return 1;

}


int cspReturnError(RCB *pRCB, char *error)
{

   char buffer[4096];

/*
pRCB->csp_form = 1;
*/
   short ws_headers = 0;

   if (pRCB && pRCB->soap) {

      strcpy(buffer, "HTTP/1.1 200 OK\r\n");
      strcat(buffer, "Content-type: text/xml\r\n");
      strcat(buffer, "Connection: close\r\n");
      strcat(buffer, "Expires: Thu, 29 Oct 1998 17:04:19 GMT\r\n");
      strcat(buffer, "Cache-Control: no-cache\r\n");
      strcat(buffer, "Pragma: no-cache\r\n");
      strcat(buffer, "\r\n");

      cspSendResponseHeader(pRCB, buffer, 0, &ws_headers, 0);
 
      strcpy(buffer, "<?xml version='1.0' encoding='UTF-8' standalone='no' ?>\r\n");
      cspWriteString(pRCB, buffer, 0);

      strcpy(buffer, "<SOAP-ENV:Envelope xmlns:SOAP-ENV='http://schemas.xmlsoap.org/soap/envelope/' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:s='http://www.w3.org/2001/XMLSchema' SOAP-ENV:encodingStyle='http://schemas.xmlsoap.org/soap/encoding/'>\r\n");
      cspWriteString(pRCB, buffer, 0);

      cspWriteString(pRCB, "<SOAP-ENV:Body>\r\n", 0);
      cspWriteString(pRCB, "<SOAP-ENV:Fault>\r\n", 0);
      cspWriteString(pRCB, "<faultcode>SOAP-ENV:Server</faultcode>\r\n", 0);

      strcpy(buffer, "<faultstring>CSP Gateway Error</faultstring>\r\n");
      cspWriteString(pRCB, buffer, 0);

      cspWriteString(pRCB, "<detail>\r\n", 0);
      cspWriteString(pRCB, "<error xmlns='http://tempuri.org' >\r\n", 0);

      cspWriteString(pRCB, "<special>\r\n", 0);
      cspWriteString(pRCB, "Service Availability Error", 0);
      cspWriteString(pRCB, "\r\n</special>\r\n", 0);

      cspWriteString(pRCB, "<text>\r\n", 0);
      cspWriteString(pRCB, error, 0);
      cspWriteString(pRCB, "\r\n</text>\r\n", 0);

      cspWriteString(pRCB, "</error>\r\n", 0);
      cspWriteString(pRCB, "</detail>\r\n", 0);
      cspWriteString(pRCB, "</SOAP-ENV:Fault>\r\n", 0);
      cspWriteString(pRCB, "</SOAP-ENV:Body>\r\n", 0);
      cspWriteString(pRCB, "</SOAP-ENV:Envelope>\r\n", 0);

      return 1;
   }

   if (pRCB->csp_form && !pRCB->debug) {

      if (strlen(pRCB->error_redir)) {

         strcpy(buffer, "HTTP/1.1 301 REDIRECT\r\n");
         strcat(buffer, "Location: ");
         strcat(buffer, pRCB->error_redir);
         strcat(buffer, "\r\n");
         strcat(buffer, "Connection: close");
         strcat(buffer, "\r\n\r\n");

         ws_headers = 0;
         cspSendResponseHeader(pRCB, buffer, 0, &ws_headers, 0);

      }
      else {

         strcpy(buffer, "HTTP/1.1 503 Service Unavailable\r\n");
         strcat(buffer, "Content-type: text/html\r\n");
         strcat(buffer, "Connection: close\r\n\r\n");

         ws_headers = 0;
         cspSendResponseHeader(pRCB, buffer, 0, &ws_headers, 0);

         cspWriteString(pRCB, "<HTML>\r\n", 0);
         cspWriteString(pRCB, "<HEAD><TITLE>Service Availability Error</TITLE></HEAD>\r\n", 0);
         cspWriteString(pRCB, "<BODY>\r\n", 0);
         cspWriteString(pRCB, "<H2>The Service you requested is currently unavailable.</H2>\r\n", 0);
         cspWriteString(pRCB, "<P>Please try again later.\r\n", 0);
         cspWriteString(pRCB, "</BODY>\r\n", 0);
         cspWriteString(pRCB, "</HTML>\r\n", 0);
      }
   }
   else {
      strcpy(buffer, "HTTP/1.1 200 OK\r\n");
      strcat(buffer, "Content-type: text/html\r\n");
      strcat(buffer, "Connection: close\r\n\r\n");

      ws_headers = 0;
      cspSendResponseHeader(pRCB, buffer, 0, &ws_headers, 0);

      cspWriteString(pRCB, "<HTML>\r\n", 0);
      cspWriteString(pRCB, "<HEAD><TITLE>Cach&eacute; Server Pages Connection Error</TITLE></HEAD>\r\n", 0);
      cspWriteString(pRCB, "<BODY>\r\n", 0);
      cspWriteString(pRCB, "<H2>An error occurred while attempting to communicate with the Cach&eacute; Server Pages Network Service Daemon</H2>\r\n", 0);
      cspWriteString(pRCB, "<P>\r\n", 0);
      cspWriteString(pRCB, error, 0);
      cspWriteString(pRCB, "\r\n</BODY>\r\n", 0);
      cspWriteString(pRCB, "</HTML>\r\n", 0);
   }

   return 1;
}


int cspReturnAuthorization(RCB *pRCB)
{
   char buffer[4096];

   strcpy(buffer, "HTTP/1.1 401 Authorization Required\r\n");
   strcat(buffer, "WWW-Authenticate: Basic realm=\"CSP Application\"\r\n");
   strcat(buffer, "Content-Type: text/html\r\n");
   strcat(buffer, "Connection: close\r\n\r\n");

   short ws_headers = 0;
   cspSendResponseHeader(pRCB, buffer, 0, &ws_headers, 0);

   cspWriteString(pRCB, "<html>\r\n", 0);
   cspWriteString(pRCB, "<head><title>401 Authorization Required</title></head><body>\r\n", 0);
   cspWriteString(pRCB, "<h1>Authorization Required</h1>\r\n", 0);
   cspWriteString(pRCB, "<p>\r\n", 0);
   cspWriteString(pRCB, "The Cache server could not verify that you are authorized to access the application.  Check your user name and password\r\n", 0);
   cspWriteString(pRCB, "</p>\r\n", 0);
   cspWriteString(pRCB, "<hr>\r\n", 0);
   cspWriteString(pRCB, "</body>\r\n", 0);
   cspWriteString(pRCB, "</html>\r\n", 0);

   return 1;
}


int cspReturnRequestBlock(RCB *pRCB, LPMEMOBJ lp_trans_buffer)
{
   int n;
   char buffer[256], buffer1[256];

   buffer[1] = '\0';

   strcpy(buffer, "HTTP/1.1 200 OK\r\n");
   strcat(buffer, "Content-type: text/html\r\n");
   strcat(buffer, "Connection: close\r\n\r\n");

   short ws_headers = 0;
   cspSendResponseHeader(pRCB, buffer, 0, &ws_headers, 0);

   cspWriteString(pRCB, "<HTML>\r\n", 0);
   cspWriteString(pRCB, "<HEAD><TITLE>Cach&eacute; Server Pages Request Block</TITLE></HEAD>\r\n", 0);
   cspWriteString(pRCB, "<BODY>\r\n", 0);
   cspWriteString(pRCB, "<H2>Cach&eacute; Server Pages Request Block ...</H2>\r\n", 0);
   cspWriteString(pRCB, "<P>\r\n", 0);

   sprintf(buffer, "Request Number for this Apache Process: %lu", request_no);
   cspWriteString(pRCB, buffer, 0);
   cspWriteString(pRCB, "<P>\r\n", 0);

   strcpy(buffer1, CSP_FILE_TYPES);
   for (n = 0; buffer1[n]; n ++) {
      if (buffer1[n] == '.')
         buffer1[n] = ' ';
   }
   strcpy(buffer, "Core CSP File Types: ");
   strcat(buffer, buffer1);

   if (pRCB->dconf && strlen(pRCB->dconf->csp_file_types))
      strcpy(buffer1, pRCB->dconf->csp_file_types);
   else if (pRCB->sconf && strlen(pRCB->sconf->csp_file_types))
      strcpy(buffer1, pRCB->sconf->csp_file_types);
   else
      strcpy(buffer1, "");

   if (strlen(buffer1)) {
      for (n = 0; buffer1[n]; n ++) {
         if (buffer1[n] == '.')
            buffer1[n] = ' ';
      }
      strcat(buffer, "; Additional CSP File Types: ");
      strcat(buffer, buffer1);
   }
   cspWriteString(pRCB, buffer, 0);
   cspWriteString(pRCB, "<P>\r\n", 0);

   buffer[1] = '\0';
   for (n = 0; n < lp_trans_buffer->curr_size; n ++) {
      if (lp_trans_buffer->lp_buffer[n] == '\r')
         cspWriteString(pRCB, "\r\n<BR>\r\n", 0);
      else {
         buffer[0] = lp_trans_buffer->lp_buffer[n];
         cspWriteString(pRCB, buffer, 0);
      }
   }

   cspWriteString(pRCB, "\r\n</BODY>\r\n", 0);
   cspWriteString(pRCB, "</HTML>\r\n", 0);

   return 1;
}


/* Return data to client */

int cspWriteString(RCB *pRCB, char *buffer, short context)
{
   int size;

   size = (int) (strlen(buffer) * sizeof(char));

   if (!pRCB->ws_buffer) {
      pRCB->ws_buffer = (unsigned char *) malloc(sizeof(char) * 8192);
      if (pRCB->ws_buffer)
         pRCB->ws_buffer_size = 8192; /* CMT805 */
   }

   if ((size + pRCB->ws_buffer_ptr) < pRCB->ws_buffer_size) {
      memcpy((void *) (pRCB->ws_buffer + pRCB->ws_buffer_ptr), (void *) buffer, size);
      pRCB->ws_buffer_ptr += size;
      return 1;
   }
   else {
      cspWriteBuffer(pRCB, pRCB->ws_buffer, pRCB->ws_buffer_ptr, 0);
      pRCB->ws_buffer_ptr = 0;
      if (size < pRCB->ws_buffer_size) {
         memcpy((void *) (pRCB->ws_buffer + pRCB->ws_buffer_ptr), (void *) buffer, size);
         pRCB->ws_buffer_ptr += size;
      }
      else {
         cspWriteBuffer(pRCB, buffer, size, 0);
      }
   }

   return 1;
}


int cspWriteBuffer(RCB *pRCB, void *buffer, int size, short context)
{
   int written, nflush;

/*
   ap_log_rerror(APLOG_MARK, APLOG_NOTICE, 0, pRCB->r, "mod_csp: cspWriteBuffer: context=%d; size=%d;", context, size);
*/
   if ((written = CSP_RWRITE(buffer, size, pRCB->r)) == EOF)
	   return 0;
   else
      nflush = CSP_RFLUSH(pRCB->r);

   return 1;

}


int cspServerVariable(void *rec, const char *key, const char *value)
{
   short ok;
   int n;
   char *pvar;
   char buffer[128];
   CSPIFC * p_cspifc;
   RCB *pRCB;
   LPMEMOBJ lp_cgievar, lp_trans_buffer;

   if (!rec || !key || !value)
      return 0;

   p_cspifc = (CSPIFC *) rec;
   pRCB = (RCB *) p_cspifc->p1;

   if (p_cspifc->context == 0) {
      lp_trans_buffer = (LPMEMOBJ) p_cspifc->p2;

      if (strstr((char *) key, "CONTENT_TYPE") && strstr((char *) value, "/xml"))
         pRCB->soap = 1;
      if (strstr((char *) key, "HTTP_SOAPACTION"))
         pRCB->soap = 1;

      ok = 1;
      for (n = 0; n < CSP_MAX_CGIS; n ++) {
         if (!strcmp(CgiEnvVarsS[n], (char *) key)) {
            ok = 0;
            break;
         }

      }
      if (ok) {
         cspMemCat(lp_trans_buffer, (char *) key, strlen((char *) key));
         cspMemCat(lp_trans_buffer, "=", 1);
         cspMemCat(lp_trans_buffer, (char *) value, strlen((char *) value));
         cspMemCat(lp_trans_buffer, "\r", 1);
      }
   }
   else if (p_cspifc->context == 1) {
      lp_cgievar = (LPMEMOBJ) p_cspifc->p2;
      cspMemCat(lp_cgievar, (char *) key, strlen((char *) key));
      cspMemCat(lp_cgievar, "=", 1);
      cspMemCat(lp_cgievar, (char *) value, strlen((char *) value));
      cspMemCat(lp_cgievar, "<BR>", 4);
   }
   else if (p_cspifc->context == 2) {
      lp_cgievar = (LPMEMOBJ) p_cspifc->p2;
      pvar = (char *) p_cspifc->p3;

      strncpy(buffer, (char *) key, 120);
      buffer[120] = '\0';
      cspLCase((char *) buffer);

      if (!strcmp(pvar, buffer)) {
         p_cspifc->defined = 1;
         cspMemCpy(lp_cgievar, (char *) value, strlen((char *) value));
      }
   }

   return 1;
}


int cspGetServerVariable(RCB *pRCB, char *VariableName, LPMEMOBJ lp_cgievar)
{
   int ok;
   table *e;
   char *result;
   const char *sent_pw;

   ok = 0;
   e = pRCB->r->subprocess_env;
   result = NULL;

   cspMemCpy(lp_cgievar, "", 0);

   /* Mostly, we just grab it from the environment, but there are
    * a couple of special cases
    */

   if (!strcmp(VariableName, "ALL_ENV")) {
      CSPIFC cspifc;

      cspifc.context = 1;
      cspifc.p1 = (void *) pRCB;
      cspifc.p2 = (void *) lp_cgievar;

      CSP_TABLE_DO(cspServerVariable, (void *) &cspifc, e, NULL);
      ok = 1;
   }
   else if (!strcmp(VariableName, "CSP_MODULE_TYPE")) {
      cspMemCpy(lp_cgievar, CSP_MODULE_TYPE, strlen(CSP_MODULE_TYPE));
      ok = 1;
      return lp_cgievar->curr_size;
   }
   else if (!strcmp(VariableName, "CSP_MODULE_BUILD")) {
      char buffer[32];

      sprintf(buffer, "%d", csp_module_build);
      cspMemCpy(lp_cgievar, buffer, strlen(buffer));
      ok = 1;
      return lp_cgievar->curr_size;
   }
   else if (!strcmp(VariableName, "CSP_SERVER_PORT_LOCAL")) { /* CMT1319 */
      int port;
      char buffer[32];

      port = pRCB->r->parsed_uri.port;
      if (pRCB->r->connection && pRCB->r->connection->local_addr) {
         port = pRCB->r->connection->local_addr->port;
      }
      sprintf(buffer, "%d", port);
      cspMemCpy(lp_cgievar, buffer, strlen(buffer));
      ok = 1;
      return lp_cgievar->curr_size;
   }

   if (!strcasecmp(VariableName, "UNMAPPED_REMOTE_USER")) {

	   /* We don't support NT users, so this is always the same as
	    * REMOTE_USER
	    */

      result = (char *) CSP_TABLE_GET(e, "REMOTE_USER");
      ok = 1;
   }
   else if (!strcasecmp(VariableName, "AUTH_PASSWORD")) {

      int res;

      if ((res = ap_get_basic_auth_pw(pRCB->r, &sent_pw)) == OK)
         result = (char *) sent_pw;
   }
   else if (!strcasecmp(VariableName, "HTTP_AUTHORIZATION")) {

      table *e_head;
      CSPIFC cspifc;

      e_head = pRCB->r->headers_in;
      cspifc.context = 2;
      cspifc.defined = 0;
      cspifc.p1 = (void *) pRCB;
      cspifc.p2 = (void *) lp_cgievar;
      cspifc.p3 = (void *) "authorization";

      CSP_TABLE_DO(cspServerVariable, (void *) &cspifc, e_head, NULL);
      if (cspifc.defined)
         ok = lp_cgievar->curr_size;
      else
         ok = -1;

      return ok;
   }
   else if (!strcasecmp(VariableName, "SERVER_PORT_SECURE")) {

	   /* Apache doesn't support secure requests inherently, so
	    * we have no way of knowing. We'll be conservative, and say
	    * all requests are insecure.
	    */

      result = "0";
      ok = 1;
   }
   else if (!strcasecmp(VariableName, "URL") || !strcasecmp(VariableName, "SCRIPT_NAME")) {
	   result = pRCB->r->uri;
   }
   else if (!strcasecmp(VariableName, "PATH_TRANSLATED")) {

	   result = (char *) CSP_TABLE_GET(e, "DOCUMENT_ROOT");
      if (result) {
         cspMemCpy(lp_cgievar, result, strlen(result));
         if (pRCB->r->uri)
            cspMemCat(lp_cgievar, pRCB->r->uri, strlen(pRCB->r->uri));

         ok = 1;
         return lp_cgievar->curr_size;

      }
      else
   	   result = (char *) CSP_TABLE_GET(e, VariableName);

   }
   else {
	   result = (char *) CSP_TABLE_GET(e, VariableName);
   }

   if (result) {
      cspMemCpy(lp_cgievar, result, strlen(result));
      ok = 1;
   }
   else if (!strcasecmp(VariableName, "CONTENT_LENGTH")) {
      cspMemCpy(lp_cgievar, "0", 1);
      ok = 1;
   }


   if (ok)
      ok = (int) lp_cgievar->curr_size;
   else
      ok = -1;

   return ok;

}


int cspGetReqVars(RCB *pRCB, LPMEMOBJ lp_cgievar)
{
   int result;
   char request_transfer_encoding[32];

   result = 1;

   pRCB->clen = 0;
   pRCB->request_chunked = 0;
   request_transfer_encoding[0] = '\0';

   cspGetServerVariable(pRCB, "CONTENT_LENGTH", lp_cgievar);
   pRCB->clen = strtol(lp_cgievar->lp_buffer, NULL, 10);

   if (cspGetServerVariable(pRCB, "HTTP_TRANSFER_ENCODING", lp_cgievar) < 128) {
      strncpy(request_transfer_encoding, (char *) lp_cgievar->lp_buffer, 31);
      request_transfer_encoding[31] = '\0';
   }

   if (*request_transfer_encoding) {
      cspLCase(request_transfer_encoding);
      if (strstr(request_transfer_encoding, "chunked")) {
         pRCB->request_chunked = 1;
      }
   }
   return result;
}



int cspMemInit(LPMEMOBJ lp_mem_obj, int size, int incr_size)
{
   int result;

   lp_mem_obj->lp_buffer = (char *) malloc(sizeof(char) * (size + 1));
   if (lp_mem_obj->lp_buffer) {
      *(lp_mem_obj->lp_buffer) = '\0';
      result = 1;
   }
   else {
      result = 0;
      lp_mem_obj->lp_buffer = (char *) malloc(sizeof(char));
      if (lp_mem_obj->lp_buffer) {
         *(lp_mem_obj->lp_buffer) = '\0';
         size = 1;
      }
      else
         size = 0;
   }

   lp_mem_obj->size = size;
   lp_mem_obj->incr_size = incr_size;
   lp_mem_obj->curr_size = 0;

   return result;
}


int cspMemFree(LPMEMOBJ lp_mem_obj)
{
   if (lp_mem_obj->lp_buffer)
      free((void *) lp_mem_obj->lp_buffer);

   lp_mem_obj->lp_buffer = NULL;
   lp_mem_obj->size = 0;
   lp_mem_obj->incr_size = 0;
   lp_mem_obj->curr_size = 0;

   return 1;
}


int cspMemCpy(LPMEMOBJ lp_mem_obj, char *buffer, int buffer_len)
{
   int result, req_size, size, incr_size;

   result = 1;

   if (buffer_len < 1) {
      req_size = 0;
      lp_mem_obj->lp_buffer[req_size] = '\0';
      lp_mem_obj->curr_size = req_size;
      return result;
   }

   req_size = buffer_len;
   if (req_size > lp_mem_obj->size) {
      size = lp_mem_obj->size;
      incr_size = lp_mem_obj->incr_size;
      while (req_size > size)
         size = size + lp_mem_obj->incr_size;
      cspMemFree(lp_mem_obj);
      result = cspMemInit(lp_mem_obj, size, incr_size);
   }
   if (result) {
      memcpy((void *) lp_mem_obj->lp_buffer, (void *) buffer, buffer_len);
      lp_mem_obj->lp_buffer[req_size] = '\0';
      lp_mem_obj->curr_size = req_size;
   }

   return result;
}


int cspMemCat(LPMEMOBJ lp_mem_obj, char *buffer, int buffer_len)
{
   int result, req_size, size, incr_size, curr_size;
   char *lp_temp;

   result = 1;

   if (buffer_len < 1)
      return result;

   req_size = (int) (buffer_len + lp_mem_obj->curr_size);
   curr_size = lp_mem_obj->curr_size;

   if (req_size > lp_mem_obj->size) {
      size = lp_mem_obj->size;
      incr_size = lp_mem_obj->incr_size;
      while (req_size > size)
         size = size + lp_mem_obj->incr_size;
      lp_temp = lp_mem_obj->lp_buffer;
      result = cspMemInit(lp_mem_obj, size, incr_size);
      if (result) {
         if (lp_temp) {
            memcpy((void *) lp_mem_obj->lp_buffer, (void *) lp_temp, curr_size);
            lp_mem_obj->curr_size = curr_size;
            free((void *) lp_temp);
         }
      }
      else
         lp_mem_obj->lp_buffer = lp_temp;
   }
   if (result) {
      memcpy((void *) (lp_mem_obj->lp_buffer + curr_size), (void *) buffer, buffer_len);
      lp_mem_obj->lp_buffer[req_size] = '\0';
      lp_mem_obj->curr_size = req_size;
   }

   return result;
}



int cspLCase(char *string)
{

#if defined(_WIN32) && defined(_UNICODE)

   CharLower(string);
   return 1;

#else

   int n, chr;

   n = 0;
   while (string[n] != '\0') {
      chr = (int) string[n];
      if (chr >= 65 && chr <= 90)
         string[n] = (char) (chr + 32);
      n ++;
   }
   return 1;

#endif

}


int cspLogEvent(char *event, char *title)
{
   int n;
   FILE *fp = NULL;
   char timestr[64], heading[256];
   time_t now = 0;
/*
   ap_log_error(APLOG_MARK, APLOG_NOTICE, OK, NULL, "%s: %s", title, event);
*/
   now = time(NULL);
   sprintf(timestr, "%s", ctime(&now));
   for (n = 0; timestr[n] != '\0'; n ++) {
      if ((unsigned int) timestr[n] < 32) {
         timestr[n] = '\0';
         break;
      }
   }

   sprintf(heading, ">>> Time: %s; Build: %d", timestr, csp_module_build);

   fp = fopen(CSP_LOG_FILE, "a");
   if (fp) {

      fputs(heading, fp);
      fputs("\r\n    ", fp);
      fputs(title, fp);
      fputs("\r\n    ", fp);
      fputs(event, fp);
      fputs("\r\n", fp);

      fclose(fp);
   }

   return 1;

}


int cspLog(RCB *pRCB, char *buffer, int size)
{

   pRCB->fp = fopen(pRCB->file, "ab");
   if (pRCB->fp) {
      fputs(buffer,  pRCB->fp);
      fclose(pRCB->fp);
      pRCB->fp = NULL;
   }

   return 1;
}


int cspLoadNet(int context)
{
#ifdef _WIN32
   int result, retval;
   WORD VersionRequested;
   char buffer[1024], path[32];

   result = 1;
   retval = 0;
   *buffer = '\0';
   *path = '\0';

#ifdef CSP_WINSOCK2

   if (csp_sock.load_attempted)
      return result;

#if CSP_USE_THREADS
   if (context == 0) {
      if (cspcon_lock)
         retval = apr_thread_mutex_lock(cspcon_lock);
   }
#endif

   if (csp_sock.load_attempted)
      goto cspLoadNetExit;

   csp_sock.sock = 0;

#if defined(CSP_IPV6)
   csp_sock.ipv6 = 1;
#else
   csp_sock.ipv6 = 0;
#endif

   /* Try to Load the Winsock 2 library */

   csp_sock.winsock = 2;
   strcpy(path, "WS2_32.DLL");
   csp_sock.h_sock = LoadLibrary(path);
   if (!csp_sock.h_sock) {
      csp_sock.winsock = 1;
      strcpy(path, "WSOCK32.DLL");
      csp_sock.h_sock = LoadLibrary(path);
   }

   if (!csp_sock.h_sock) {
      ap_log_error(APLOG_MARK, APLOG_NOTICE, 0, NULL, "mod_csp: Initialization Error: Cannot load Winsock library");
      goto cspLoadNetExit;
   }

   csp_sock.p_WSASocket             = (LPFN_WSASOCKET)              GetProcAddress(csp_sock.h_sock, "WSASocketA");
   csp_sock.p_WSAGetLastError       = (LPFN_WSAGETLASTERROR)        GetProcAddress(csp_sock.h_sock, "WSAGetLastError");
   csp_sock.p_WSAStartup            = (LPFN_WSASTARTUP)             GetProcAddress(csp_sock.h_sock, "WSAStartup");
   csp_sock.p_WSACleanup            = (LPFN_WSACLEANUP)             GetProcAddress(csp_sock.h_sock, "WSACleanup");
   csp_sock.p_WSAFDIsSet            = (LPFN_WSAFDISSET)             GetProcAddress(csp_sock.h_sock, "__WSAFDIsSet");
   csp_sock.p_WSARecv               = (LPFN_WSARECV)                GetProcAddress(csp_sock.h_sock, "WSARecv");
   csp_sock.p_WSASend               = (LPFN_WSASEND)                GetProcAddress(csp_sock.h_sock, "WSASend");
   csp_sock.p_closesocket           = (LPFN_CLOSESOCKET)            GetProcAddress(csp_sock.h_sock, "closesocket");
   csp_sock.p_gethostbyname         = (LPFN_GETHOSTBYNAME)          GetProcAddress(csp_sock.h_sock, "gethostbyname");

#if defined(CSP_IPV6)
   csp_sock.p_getaddrinfo           = (LPFN_GETADDRINFO)            GetProcAddress(csp_sock.h_sock, "getaddrinfo");
   csp_sock.p_freeaddrinfo          = (LPFN_FREEADDRINFO)           GetProcAddress(csp_sock.h_sock, "freeaddrinfo");
#else
   csp_sock.p_getaddrinfo           = NULL;
   csp_sock.p_freeaddrinfo          = NULL;
#endif

   csp_sock.p_htons                 = (LPFN_HTONS)                  GetProcAddress(csp_sock.h_sock, "htons");
   csp_sock.p_htonl                 = (LPFN_HTONL)                  GetProcAddress(csp_sock.h_sock, "htonl");
   csp_sock.p_connect               = (LPFN_CONNECT)                GetProcAddress(csp_sock.h_sock, "connect");
   csp_sock.p_inet_addr             = (LPFN_INET_ADDR)              GetProcAddress(csp_sock.h_sock, "inet_addr");
   csp_sock.p_socket                = (LPFN_SOCKET)                 GetProcAddress(csp_sock.h_sock, "socket");
   csp_sock.p_setsockopt            = (LPFN_SETSOCKOPT)             GetProcAddress(csp_sock.h_sock, "setsockopt");
   csp_sock.p_getsockopt            = (LPFN_GETSOCKOPT)             GetProcAddress(csp_sock.h_sock, "getsockopt");
   csp_sock.p_select                = (LPFN_SELECT)                 GetProcAddress(csp_sock.h_sock, "select");
   csp_sock.p_recv                  = (LPFN_RECV)                   GetProcAddress(csp_sock.h_sock, "recv");
   csp_sock.p_send                  = (LPFN_SEND)                   GetProcAddress(csp_sock.h_sock, "send");
   csp_sock.p_shutdown              = (LPFN_SHUTDOWN)               GetProcAddress(csp_sock.h_sock, "shutdown");
   csp_sock.p_bind                  = (LPFN_BIND)                   GetProcAddress(csp_sock.h_sock, "bind");


   if (   (csp_sock.p_WSASocket              == NULL && csp_sock.winsock == 2)
       ||  csp_sock.p_WSAGetLastError        == NULL
       ||  csp_sock.p_WSAStartup             == NULL
       ||  csp_sock.p_WSACleanup             == NULL
       ||  csp_sock.p_WSAFDIsSet             == NULL
       || (csp_sock.p_WSARecv                == NULL && csp_sock.winsock == 2)
       || (csp_sock.p_WSASend                == NULL && csp_sock.winsock == 2)
       ||  csp_sock.p_closesocket            == NULL
       ||  csp_sock.p_gethostbyname          == NULL
       ||  csp_sock.p_htons                  == NULL
       ||  csp_sock.p_htonl                  == NULL
       ||  csp_sock.p_connect                == NULL
       ||  csp_sock.p_inet_addr              == NULL
       ||  csp_sock.p_socket                 == NULL
       ||  csp_sock.p_setsockopt             == NULL
       ||  csp_sock.p_getsockopt             == NULL
       ||  csp_sock.p_select                 == NULL
       ||  csp_sock.p_recv                   == NULL
       ||  csp_sock.p_send                   == NULL
       ||  csp_sock.p_shutdown               == NULL
       ||  csp_sock.p_bind                   == NULL
      ) {

      sprintf(buffer, "mod_csp: Initialization Error: Cannot use Winsock library (WSASocket=%x; WSAGetLastError=%x; WSAStartup=%x; WSACleanup=%x; WSAFDIsSet=%x; WSARecv=%x; WSASend=%x; closesocket=%x; gethostbyname=%x; getaddrinfo=%x; freeaddrinfo=%x; htons=%x; htonl=%x; connect=%x; inet_addr=%x; socket=%x; setsockopt=%x; getsockopt=%x; select=%x; recv=%x; p_send=%x; shutdown=%x; bind=%x)",
            csp_sock.p_WSASocket,
            csp_sock.p_WSAGetLastError,
            csp_sock.p_WSAStartup,
            csp_sock.p_WSACleanup,
            csp_sock.p_WSAFDIsSet,
            csp_sock.p_WSARecv,
            csp_sock.p_WSASend,
            csp_sock.p_closesocket,
            csp_sock.p_gethostbyname,
            csp_sock.p_getaddrinfo,
            csp_sock.p_freeaddrinfo,
            csp_sock.p_htons,
            csp_sock.p_htonl,
            csp_sock.p_connect,
            csp_sock.p_inet_addr,
            csp_sock.p_socket,
            csp_sock.p_setsockopt,
            csp_sock.p_getsockopt,
            csp_sock.p_select,
            csp_sock.p_recv,
            csp_sock.p_send,
            csp_sock.p_shutdown,
            csp_sock.p_bind
            );
      ap_log_error(APLOG_MARK, APLOG_NOTICE, 0, NULL, buffer);
      FreeLibrary(csp_sock.h_sock);
   }
   else {
      csp_sock.sock = 1;
   }

   result = csp_sock.sock;
   csp_sock.load_attempted = 1;
   csp_sock.wsastartup = -1;

   if (csp_sock.p_getaddrinfo == NULL ||  csp_sock.p_freeaddrinfo == NULL)
      csp_sock.ipv6 = 0;

cspLoadNetExit:

#if CSP_USE_THREADS
   if (context == 0) {
      if (cspcon_lock)
         retval = apr_thread_mutex_unlock(cspcon_lock);
   }
#endif

   if (result) {

      if (csp_sock.winsock == 2)
         VersionRequested = MAKEWORD(2, 2);
      else
         VersionRequested = MAKEWORD(1, 1);

      csp_sock.wsastartup = CSPNET_WSASTARTUP(VersionRequested, &(csp_sock.wsadata));
      if (csp_sock.wsastartup != 0 && csp_sock.winsock == 2) {
         VersionRequested = MAKEWORD(2, 0);
         csp_sock.wsastartup = CSPNET_WSASTARTUP(VersionRequested, &(csp_sock.wsadata));
         if (csp_sock.wsastartup != 0) {
            csp_sock.winsock = 1;
            VersionRequested = MAKEWORD(1, 1);
            csp_sock.wsastartup = CSPNET_WSASTARTUP(VersionRequested, &(csp_sock.wsadata));
         }
      }
      if (csp_sock.wsastartup == 0) {
         if ((csp_sock.winsock == 2 && LOBYTE(csp_sock.wsadata.wVersion) != 2)
               || (csp_sock.winsock == 1 && (LOBYTE(csp_sock.wsadata.wVersion) != 1 || HIBYTE(csp_sock.wsadata.wVersion) != 1))) {
  
            sprintf(buffer, "mod_csp: Initialization Error: Wrong version of Winsock library (%d.%d)", path, LOBYTE(csp_sock.wsadata.wVersion), HIBYTE(csp_sock.wsadata.wVersion));
            ap_log_error(APLOG_MARK, APLOG_NOTICE, 0, NULL, buffer);
            CSPNET_WSACLEANUP();
            csp_sock.wsastartup = -1;
         }
         else {
            if (strlen(path))
               sprintf(buffer, "mod_csp: Initialization: Windows Sockets library loaded (%s) Version: %d.%d%s", path, LOBYTE(csp_sock.wsadata.wVersion), HIBYTE(csp_sock.wsadata.wVersion), csp_sock.ipv6 ? " (IPv6 Enabled)" : "");
            else
               sprintf(buffer, "mod_csp: Initialization: Windows Sockets library Version: %d.%d%s", LOBYTE(csp_sock.wsadata.wVersion), HIBYTE(csp_sock.wsadata.wVersion), csp_sock.ipv6 ? " (IPv6 Enabled)" : "");

            ap_log_error(APLOG_MARK, APLOG_NOTICE, 0, NULL, buffer);
         }
      }
      else {
         ap_log_error(APLOG_MARK, APLOG_NOTICE, 0, NULL, "mod_csp: Initialization Error: Unusable Winsock library");
      }
   }

#else

   if (csp_sock.winsock)
      return 1;

   csp_sock.ipv6 = 0;
   csp_sock.winsock = 1;
   csp_sock.wsastartup = -1;

   VersionRequested = MAKEWORD(1, 1);
   csp_sock.wsastartup = CSPNET_WSASTARTUP(VersionRequested, &(csp_sock.wsadata));
   if (csp_sock.wsastartup == 0) {
      if (LOBYTE(csp_sock.wsadata.wVersion) != 1 || HIBYTE(csp_sock.wsadata.wVersion) != 1) {
         sprintf(buffer, "mod_csp: Initialization Error: Wrong version of Winsock library (%d.%d)", path, LOBYTE(csp_sock.wsadata.wVersion), HIBYTE(csp_sock.wsadata.wVersion));
         ap_log_error(APLOG_MARK, APLOG_NOTICE, 0, NULL, buffer);
         CSPNET_WSACLEANUP();
         csp_sock.wsastartup = -1;
      }
      else {
         sprintf(buffer, "mod_csp: Initialization: Windows Sockets library Version: %d.%d", LOBYTE(csp_sock.wsadata.wVersion), HIBYTE(csp_sock.wsadata.wVersion));
         ap_log_error(APLOG_MARK, APLOG_NOTICE, 0, NULL, buffer);
      }
   }
   else {
      ap_log_error(APLOG_MARK, APLOG_NOTICE, 0, NULL, "mod_csp: Initialization Error: Unusable Winsock library");
   }


#endif /* #ifdef CSP_WINSOCK2 */

#else

   if (csp_sock.load_attempted)
      return 1;
   csp_sock.load_attempted = 1;

#if defined(CSP_IPV6)
   csp_sock.ipv6 = 1;
#else
   csp_sock.ipv6 = 0;
#endif

#endif /* #ifdef _WIN32 */

   return 1;

}


int cspUnLoadNet(int context)
{
#ifdef _WIN32
#ifdef CSP_WINSOCK2
   if (csp_sock.sock) {
      if (csp_sock.wsastartup == 0)
         CSPNET_WSACLEANUP();

      FreeLibrary(csp_sock.h_sock);
   }
#else
   if (csp_sock.wsastartup == 0)
      CSPNET_WSACLEANUP();
#endif
   csp_sock.wsastartup = -1;
#endif
   return 1;
}

